/* ==========================================================================
   FLOW — Personal Productivity OS
   Vanilla JS (ES module), no frameworks/libraries.
   Architecture: small single-responsibility modules (SRP) communicating
   through a shared Store (localStorage) and a tiny pub/sub event bus.
   Each "manager" below is a self-contained component: it owns a slice of
   state, renders its own DOM, and exposes an init()/render() surface.
   ========================================================================== */

/* ============================================================
   0. UTILITIES  (pure helpers — DRY building blocks used everywhere)
   ============================================================ */
const $  = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

const uid = () => `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`;

const clamp = (n, min, max) => Math.min(max, Math.max(min, n));

const pad2 = (n) => String(n).padStart(2, '0');

/** Format a Date to YYYY-MM-DD (local, stable key used across all managers) */
const dateKey = (d = new Date()) => `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;

/** Format ms duration -> HH:MM:SS or MM:SS */
function formatDuration(ms, withHours = true) {
  const totalSec = Math.max(0, Math.floor(ms / 1000));
  const h = Math.floor(totalSec / 3600);
  const m = Math.floor((totalSec % 3600) / 60);
  const s = totalSec % 60;
  if (withHours && h > 0) return `${pad2(h)}:${pad2(m)}:${pad2(s)}`;
  return `${pad2(m)}:${pad2(s)}`;
}

function formatHoursShort(ms) {
  const hrs = ms / 3.6e6;
  return hrs >= 1 ? `${hrs.toFixed(1)}h` : `${Math.round(ms / 60000)}m`;
}

const DAY_MS = 86400000;

function startOfDay(d) { const c = new Date(d); c.setHours(0, 0, 0, 0); return c; }
function addDays(d, n) { const c = new Date(d); c.setDate(c.getDate() + n); return c; }
function daysBetween(a, b) { return Math.round((startOfDay(b) - startOfDay(a)) / DAY_MS); }

function escapeHtml(str = '') {
  return String(str).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

function debounce(fn, wait = 300) {
  let t;
  return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), wait); };
}

/** Tiny deterministic PRNG (mulberry32) — lets us derive "stable" fake
 *  weather/AI data from a seed (e.g. today's date) instead of Math.random,
 *  so the same day always looks the same across reloads. */
function mulberry32(seed) {
  let a = seed;
  return function () {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
function seedFromString(str) {
  let h = 0;
  for (let i = 0; i < str.length; i++) { h = (h << 5) - h + str.charCodeAt(i); h |= 0; }
  return h;
}

/* ---------- Tiny pub/sub event bus (decouples managers) ---------- */
const Bus = (() => {
  const listeners = new Map();
  return {
    on(evt, fn) { if (!listeners.has(evt)) listeners.set(evt, new Set()); listeners.get(evt).add(fn); return () => listeners.get(evt).delete(fn); },
    emit(evt, payload) { (listeners.get(evt) || []).forEach((fn) => fn(payload)); },
  };
})();

/* ============================================================
   1. STORE  — single source of truth, persisted to localStorage.
   ============================================================ */
const STORAGE_KEY = 'flow_os_v1';

const DEFAULT_STATE = () => ({
  tasks: [],
  projects: [],
  events: [],
  habits: [],
  journalEntries: [],
  activity: [],       // {id, ts, type, text, icon}
  sessions: [],        // work sessions {id, taskId, projectId, start, end, activeMs, breakMs}
  notifications: [],
  goals: {},            // dateKey -> "today's main goal" text
  gamification: { xp: 0, level: 1, unlocked: {} },
  profile: {
    name: 'Alex Rivera', handle: '@alexrivera', bio: "Product designer & builder. Shipping something every week.",
    profession: 'Product Designer', joinDate: dateKey(),
    skills: ['UI Design', 'JavaScript', 'Figma', 'Writing'],
    links: [{ label: 'GitHub', url: 'https://github.com' }, { label: 'Twitter', url: 'https://twitter.com' }],
    avatar: '', banner: '',
  },
  settings: {
    themeMode: 'auto', weatherMode: 'auto', accentH: 252, animations: true,
    notifTasks: true, notifHabits: true, language: 'en', weekStart: 0,
    widgetOrder: ['goalTimer', 'productivityScore', 'todayHours', 'upcomingTasks', 'habitProgress', 'weeklyAnalytics', 'weather', 'recentActivity'],
  },
  activeTimer: null, // { taskId, projectId, start, accumActiveMs, accumBreakMs, state: 'running'|'paused', pausedAt }
});

class Store {
  constructor(key) {
    this.key = key;
    this.state = this._load();
  }
  _load() {
    try {
      const raw = localStorage.getItem(this.key);
      if (!raw) return DEFAULT_STATE();
      const parsed = JSON.parse(raw);
      // Shallow-merge with defaults so newly added fields always exist
      return { ...DEFAULT_STATE(), ...parsed, settings: { ...DEFAULT_STATE().settings, ...(parsed.settings || {}) }, gamification: { ...DEFAULT_STATE().gamification, ...(parsed.gamification || {}) }, profile: { ...DEFAULT_STATE().profile, ...(parsed.profile || {}) } };
    } catch (e) {
      console.error('Store load failed, resetting.', e);
      return DEFAULT_STATE();
    }
  }
  save() {
    try { localStorage.setItem(this.key, JSON.stringify(this.state)); }
    catch (e) { console.error('Store save failed (quota?)', e); Toast.show('Storage full — could not save.', 'error'); }
    Bus.emit('store:changed', this.state);
  }
  reset() { this.state = DEFAULT_STATE(); this.save(); }
}
const store = new Store(STORAGE_KEY);
const S = () => store.state; // shorthand accessor

/* Async-flavored persistence wrapper — batches writes to a microtask so
   many rapid mutations (e.g. drag reorder) collapse into a single write. */
const persist = (() => {
  let scheduled = false;
  return () => {
    if (scheduled) return;
    scheduled = true;
    queueMicrotask(() => { store.save(); scheduled = false; });
  };
})();

/* ============================================================
   2. TOAST + MODAL (shared UI primitives)
   ============================================================ */
const Toast = {
  show(message, type = 'info', icon) {
    const container = $('#toastContainer');
    const el = document.createElement('div');
    el.className = 'toast';
    const icons = { success: '✓', error: '⚠', info: 'ℹ', xp: '✦' };
    el.innerHTML = `<span class="toast-icon">${icon || icons[type] || 'ℹ'}</span><span>${escapeHtml(message)}</span>`;
    container.appendChild(el);
    setTimeout(() => {
      el.classList.add('toast-out');
      el.addEventListener('animationend', () => el.remove(), { once: true });
    }, 3200);
  },
};

const Modal = {
  open(title, bodyHTML, actionsHTML = '') {
    const overlay = $('#modalOverlay');
    const root = $('#modalRoot');
    root.innerHTML = `
      <div class="modal-head"><h2>${title}</h2><button class="icon-btn" id="modalCloseBtn">✕</button></div>
      <div class="modal-body">${bodyHTML}</div>
      ${actionsHTML ? `<div class="modal-actions">${actionsHTML}</div>` : ''}
    `;
    overlay.hidden = false;
    $('#modalCloseBtn').addEventListener('click', Modal.close);
    overlay.onclick = (e) => { if (e.target === overlay) Modal.close(); };
    return root;
  },
  close() { $('#modalOverlay').hidden = true; $('#modalRoot').innerHTML = ''; },
};
document.addEventListener('keydown', (e) => { if (e.key === 'Escape') Modal.close(); });

/* ============================================================
   3. ACTIVITY LOG + GAMIFICATION  (cross-cutting concerns)
   ============================================================ */
const Activity = {
  log(type, text, icon = '•') {
    S().activity.unshift({ id: uid(), ts: Date.now(), type, text, icon });
    S().activity = S().activity.slice(0, 300); // cap growth — O(1) amortized
    persist();
    Bus.emit('activity:changed');
  },
};

const LEVELS_BASE_XP = 100;
const Gamification = {
  addXp(amount, reason) {
    const g = S().gamification;
    g.xp += amount;
    let leveledUp = false;
    let needed = Gamification.xpForLevel(g.level);
    while (g.xp >= needed) {
      g.xp -= needed;
      g.level += 1;
      leveledUp = true;
      needed = Gamification.xpForLevel(g.level);
    }
    persist();
    Bus.emit('gamification:changed');
    if (reason) Toast.show(`+${amount} XP — ${reason}`, 'xp', '✦');
    if (leveledUp) Toast.show(`Level up! You're now level ${g.level} 🎉`, 'success', '🏆');
    Achievements.check();
  },
  xpForLevel(level) { return Math.round(LEVELS_BASE_XP * Math.pow(1.18, level - 1)); },
};

const ACHIEVEMENT_DEFS = [
  { id: 'first_task', label: 'First Step', icon: '🌱', test: (s) => s.tasks.some((t) => t.status === 'done') },
  { id: 'ten_tasks', label: 'Task Master', icon: '🗂', test: (s) => s.tasks.filter((t) => t.status === 'done').length >= 10 },
  { id: 'first_habit', label: 'Habit Former', icon: '🔁', test: (s) => s.habits.some((h) => Object.keys(h.log || {}).length > 0) },
  { id: 'streak_7', label: '7-Day Streak', icon: '🔥', test: (s) => s.habits.some((h) => computeStreak(h).current >= 7) },
  { id: 'first_journal', label: 'Reflector', icon: '📓', test: (s) => s.journalEntries.length >= 1 },
  { id: 'journal_10', label: 'Storyteller', icon: '📚', test: (s) => s.journalEntries.length >= 10 },
  { id: 'first_focus', label: 'Focused', icon: '🎯', test: (s) => s.sessions.length >= 1 },
  { id: 'ten_hours', label: '10-Hour Club', icon: '⏱', test: (s) => s.sessions.reduce((a, x) => a + x.activeMs, 0) >= 10 * 3.6e6 },
  { id: 'first_project', label: 'Builder', icon: '🏗', test: (s) => s.projects.length >= 1 },
  { id: 'level_5', label: 'Rising Star', icon: '⭐', test: (s) => s.gamification.level >= 5 },
];
const Achievements = {
  check() {
    const s = S();
    let unlockedNew = false;
    ACHIEVEMENT_DEFS.forEach((a) => {
      if (!s.gamification.unlocked[a.id] && a.test(s)) {
        s.gamification.unlocked[a.id] = Date.now();
        unlockedNew = true;
        Toast.show(`Achievement unlocked: ${a.label}`, 'success', a.icon);
        Activity.log('achievement', `Unlocked achievement "${a.label}"`, a.icon);
      }
    });
    if (unlockedNew) { persist(); Bus.emit('achievements:changed'); }
  },
};

/** Streak calculation shared by Habits + Achievements + Profile.
 *  O(n) single pass over a log map { 'YYYY-MM-DD': true }. */
function computeStreak(habit) {
  const log = habit.log || {};
  let current = 0; let longest = 0; let run = 0;
  const today = startOfDay(new Date());
  // walk backward from today until a gap is found (current streak)
  for (let i = 0; i < 3650; i++) {
    const key = dateKey(addDays(today, -i));
    if (log[key]) current++; else break;
  }
  // longest streak: scan all logged dates sorted
  const days = Object.keys(log).filter((k) => log[k]).sort();
  let prev = null;
  days.forEach((k) => {
    if (prev && daysBetween(new Date(prev), new Date(k)) === 1) run++; else run = 1;
    longest = Math.max(longest, run);
    prev = k;
  });
  return { current, longest };
}

/* ============================================================
   4. THEME + WEATHER MANAGER
   ============================================================ */
const WEATHER_ICONS = { sunny: '☀', rain: '🌧', cloudy: '☁', snow: '❄', fog: '🌫' };
const WEATHER_LABELS = { sunny: 'Sunny', rain: 'Rain', cloudy: 'Cloudy', snow: 'Snow', fog: 'Fog' };

const ThemeManager = {
  currentTheme: 'light',
  currentWeather: 'sunny',
  weatherData: null,

  timeTheme(hour) {
    if (hour >= 5 && hour < 12) return 'light';
    if (hour >= 12 && hour < 17) return 'neutral';
    if (hour >= 17 && hour < 19) return 'sunset';
    return 'dark';
  },

  /** Deterministic "weather" derived from today's date so it's stable
   *  across reloads without any network call (sandbox has no weather API). */
  deriveWeather(dateStr) {
    const rand = mulberry32(seedFromString(dateStr));
    const states = ['sunny', 'sunny', 'cloudy', 'rain', 'fog', 'snow'];
    const state = states[Math.floor(rand() * states.length)];
    const baseTemp = { sunny: 26, cloudy: 20, rain: 18, fog: 16, snow: 1 }[state];
    return {
      state,
      temp: Math.round(baseTemp + (rand() * 6 - 3)),
      humidity: Math.round(40 + rand() * 45),
      wind: Math.round(4 + rand() * 20),
      uv: state === 'sunny' ? Math.round(4 + rand() * 7) : Math.round(rand() * 3),
      aqi: Math.round(20 + rand() * 100),
      sunrise: '06:1' + Math.floor(rand() * 9),
      sunset: '18:' + (30 + Math.floor(rand() * 29)),
      forecast: Array.from({ length: 5 }).map((_, i) => {
        const r2 = mulberry32(seedFromString(dateStr + i));
        const s2 = states[Math.floor(r2() * states.length)];
        return { day: i, state: s2, hi: Math.round(baseTemp + r2() * 5), lo: Math.round(baseTemp - 4 - r2() * 4) };
      }),
    };
  },

  apply() {
    const settings = S().settings;
    const now = new Date();
    const theme = settings.themeMode === 'auto' ? this.timeTheme(now.getHours()) : settings.themeMode;
    const weatherInfo = this.deriveWeather(dateKey(now));
    const weather = settings.weatherMode === 'auto' ? weatherInfo.state : settings.weatherMode;
    this.currentTheme = theme;
    this.currentWeather = weather;
    this.weatherData = weatherInfo;

    document.body.dataset.theme = theme;
    document.body.dataset.weather = weather;
    document.documentElement.style.setProperty('--accent-h', settings.accentH);
    document.body.classList.toggle('no-animations', !settings.animations);

    $('#weatherChipIcon').textContent = WEATHER_ICONS[weather];
    $('#weatherChipTemp').textContent = `${weatherInfo.temp}°`;
    $('#themeToggleBtn').title = `Theme: ${theme} (click to cycle)`;

    this.renderWeatherFx(weather);
    Bus.emit('theme:changed', { theme, weather });
  },

  renderWeatherFx(weather) {
    const fx = $('#weatherFx');
    fx.innerHTML = '';
    if (weather === 'snow') {
      const frag = document.createDocumentFragment();
      for (let i = 0; i < 40; i++) {
        const flake = document.createElement('span');
        flake.className = 'snowflake';
        const size = 3 + Math.random() * 5;
        flake.style.cssText = `left:${Math.random() * 100}%; width:${size}px; height:${size}px; animation-duration:${6 + Math.random() * 8}s; animation-delay:${-Math.random() * 10}s; opacity:${0.4 + Math.random() * 0.5}`;
        frag.appendChild(flake);
      }
      fx.appendChild(frag);
    }
  },

  cycleManual() {
    const order = ['light', 'neutral', 'sunset', 'dark'];
    const cur = S().settings.themeMode === 'auto' ? this.currentTheme : S().settings.themeMode;
    const next = order[(order.indexOf(cur) + 1) % order.length];
    S().settings.themeMode = next;
    persist();
    this.apply();
    SettingsManager.syncControls();
    Toast.show(`Theme set to ${next}`, 'info');
  },

  init() {
    this.apply();
    setInterval(() => this.apply(), 60000); // re-check every minute for auto mode
  },
};

/* ============================================================
   5. CLOCK + GREETING
   ============================================================ */
const ClockManager = {
  init() {
    this.tick();
    setInterval(() => this.tick(), 1000);
  },
  tick() {
    const now = new Date();
    $('#clockTime').textContent = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const h = now.getHours();
    const greetings = h < 5 ? ['Still up?', "Burning the midnight oil"] : h < 12 ? ['Good morning', 'Rise and shine'] : h < 17 ? ['Good afternoon', 'Keep the momentum'] : h < 21 ? ['Good evening', 'Winding down nicely'] : ['Good night', 'Time to rest soon'];
    const greetEl = $('#greetingText');
    if (greetEl && greetEl.dataset.hour !== String(h)) {
      greetEl.textContent = `${greetings[0]}, ${S().profile.name.split(' ')[0]}`;
      greetEl.dataset.hour = String(h);
      $('#greetingSub').textContent = greetings[1] + '.';
    }
    Bus.emit('clock:tick', now);
  },
};

/* ============================================================
   6. NAVIGATION / ROUTER
   ============================================================ */
const Router = {
  current: 'dashboard',
  RENDERERS: {}, // view -> fn, registered by each manager below

  register(view, fn) { this.RENDERERS[view] = fn; },

  goto(view) {
    if (!$(`#view-${view}`)) return;
    $$('.view').forEach((v) => v.classList.remove('is-active'));
    $(`#view-${view}`).classList.add('is-active');
    $$('.nav-item').forEach((n) => n.classList.toggle('is-active', n.dataset.view === view));
    this.current = view;
    document.body.classList.remove('is-mobile-open');
    $('.app-shell').classList.remove('is-mobile-open');
    if (this.RENDERERS[view]) this.RENDERERS[view]();
  },

  init() {
    $('#sidebarNav').addEventListener('click', (e) => {
      const btn = e.target.closest('.nav-item');
      if (btn) this.goto(btn.dataset.view);
    });
    $('#collapseSidebarBtn').addEventListener('click', () => $('.app-shell').classList.toggle('is-collapsed'));
    $('#mobileNavBtn').addEventListener('click', () => $('.app-shell').classList.toggle('is-mobile-open'));
  },
};

/* ============================================================
   7. TASK MANAGER
   ============================================================ */
const PRIORITY_ORDER = { Critical: 0, High: 1, Medium: 2, Low: 3 };
const PRIORITY_CLASS = { Critical: 'chip-critical', High: 'chip-high', Medium: 'chip-medium', Low: 'chip-low' };

const TaskManager = {
  filters: { status: 'all', priority: 'all', category: 'all', sort: 'dueDate', query: '' },
  layout: 'list',

  all() { return S().tasks; },

  create(data) {
    const task = {
      id: uid(), title: data.title || 'Untitled task', description: data.description || '',
      priority: data.priority || 'Medium', status: 'todo', category: data.category || 'General',
      tags: data.tags || [], dueDate: data.dueDate || '', estDuration: Number(data.estDuration) || 30,
      progress: 0, subtasks: data.subtasks || [], notes: data.notes || '', attachments: data.attachments || [],
      recurring: data.recurring || 'none', color: data.color || '', projectId: data.projectId || '',
      createdAt: Date.now(), actualMs: 0,
    };
    S().tasks.push(task);
    persist();
    Activity.log('task', `Created task "${task.title}"`, '＋');
    Gamification.addXp(3, 'new task planned');
    Bus.emit('tasks:changed');
    return task;
  },

  update(id, patch) {
    const t = S().tasks.find((x) => x.id === id);
    if (!t) return;
    Object.assign(t, patch);
    persist();
    Bus.emit('tasks:changed');
  },

  remove(id) {
    S().tasks = S().tasks.filter((x) => x.id !== id);
    persist();
    Bus.emit('tasks:changed');
  },

  setStatus(id, status) {
    const t = S().tasks.find((x) => x.id === id);
    if (!t) return;
    const prev = t.status;
    t.status = status;
    if (status === 'done') {
      t.progress = 100;
      if (prev !== 'done') {
        Activity.log('task', `Completed task "${t.title}"`, '✓');
        Gamification.addXp(10, 'task completed');
        this.handleRecurrence(t);
      }
    } else if (status === 'in-progress' && prev === 'todo') {
      Activity.log('task', `Started task "${t.title}"`, '▶');
    }
    persist();
    Bus.emit('tasks:changed');
  },

  toggleSubtask(taskId, subId) {
    const t = S().tasks.find((x) => x.id === taskId);
    const sub = t?.subtasks.find((s) => s.id === subId);
    if (!sub) return;
    sub.done = !sub.done;
    t.progress = t.subtasks.length ? Math.round((t.subtasks.filter((s) => s.done).length / t.subtasks.length) * 100) : t.progress;
    persist();
    Bus.emit('tasks:changed');
  },

  handleRecurrence(task) {
    if (!task.dueDate || task.recurring === 'none') return;
    const map = { daily: 1, weekly: 7, monthly: 30 };
    const days = map[task.recurring];
    if (!days) return;
    const nextDate = dateKey(addDays(new Date(task.dueDate), days));
    this.create({ ...task, title: task.title, dueDate: nextDate, subtasks: task.subtasks.map((s) => ({ ...s, id: uid(), done: false })) });
  },

  /** Lightweight heuristic "AI" suggestion — no network call available in
   *  this sandbox, so priority/due-date suggestions are computed locally
   *  from keywords + workload, which is honest about being on-device. */
  suggest(title, description) {
    const text = `${title} ${description}`.toLowerCase();
    let priority = 'Medium';
    if (/urgent|asap|critical|deadline|now|overdue/.test(text)) priority = 'Critical';
    else if (/important|soon|review|meeting|launch/.test(text)) priority = 'High';
    else if (/someday|maybe|idea|later/.test(text)) priority = 'Low';
    const busyDays = S().tasks.filter((t) => t.status !== 'done').length;
    const daysOut = priority === 'Critical' ? 1 : priority === 'High' ? 2 : clamp(3 + Math.floor(busyDays / 4), 3, 10);
    const dueDate = dateKey(addDays(new Date(), daysOut));
    return { priority, dueDate };
  },

  categories() {
    return Array.from(new Set(S().tasks.map((t) => t.category).filter(Boolean)));
  },

  filtered() {
    let list = this.all();
    const f = this.filters;
    if (f.status !== 'all') list = list.filter((t) => t.status === f.status);
    if (f.priority !== 'all') list = list.filter((t) => t.priority === f.priority);
    if (f.category !== 'all') list = list.filter((t) => t.category === f.category);
    if (f.query) list = list.filter((t) => t.title.toLowerCase().includes(f.query) || t.description.toLowerCase().includes(f.query));
    const sorters = {
      dueDate: (a, b) => (a.dueDate || '9999').localeCompare(b.dueDate || '9999'),
      priority: (a, b) => PRIORITY_ORDER[a.priority] - PRIORITY_ORDER[b.priority],
      created: (a, b) => b.createdAt - a.createdAt,
      progress: (a, b) => b.progress - a.progress,
    };
    return [...list].sort(sorters[f.sort] || sorters.dueDate);
  },

  renderCategoryOptions() {
    const sel = $('#taskCategoryFilter');
    const current = sel.value;
    sel.innerHTML = '<option value="all">All categories</option>' + this.categories().map((c) => `<option value="${escapeHtml(c)}">${escapeHtml(c)}</option>`).join('');
    sel.value = current && this.categories().includes(current) ? current : 'all';
  },

  render() {
    this.renderCategoryOptions();
    $('#taskBadge').textContent = this.all().filter((t) => t.status !== 'done').length;
    const list = this.filtered();
    if (this.layout === 'list') {
      $('#taskList').hidden = false; $('#taskBoard').hidden = true;
      this.renderList(list);
    } else {
      $('#taskList').hidden = true; $('#taskBoard').hidden = false;
      this.renderBoard(list);
    }
  },

  renderList(list) {
    const container = $('#taskList');
    if (!list.length) { container.innerHTML = emptyState('✓', 'No tasks match your filters', 'Try clearing filters or add a new task.'); return; }
    container.innerHTML = list.map((t) => this.taskItemHTML(t)).join('');
  },

  taskItemHTML(t) {
    const dueBadge = t.dueDate ? `<span class="chip">📅 ${t.dueDate}</span>` : '';
    const subDone = t.subtasks.filter((s) => s.done).length;
    return `
    <div class="task-item card priority-${t.priority} ${t.status === 'done' ? 'is-done' : ''}" data-id="${t.id}" style="${t.color ? `border-left-color:${t.color}` : ''}">
      <button class="task-checkbox ${t.status === 'done' ? 'checked' : ''}" data-action="toggle-done" data-id="${t.id}">${t.status === 'done' ? '✓' : ''}</button>
      <div class="task-main" data-action="open-task" data-id="${t.id}">
        <div class="task-title-row">
          <span class="task-title">${escapeHtml(t.title)}</span>
          <span class="chip ${PRIORITY_CLASS[t.priority]}">${t.priority}</span>
          <span class="chip">${escapeHtml(t.category)}</span>
          ${t.tags.map((tag) => `<span class="chip">#${escapeHtml(tag)}</span>`).join('')}
        </div>
        ${t.description ? `<p class="task-desc">${escapeHtml(t.description)}</p>` : ''}
        <div class="task-meta">
          ${dueBadge}
          <span class="chip">⏱ ${t.estDuration}m est</span>
          ${t.subtasks.length ? `<span class="chip">☑ ${subDone}/${t.subtasks.length}</span>` : ''}
          ${t.actualMs ? `<span class="chip">✓ ${formatHoursShort(t.actualMs)} logged</span>` : ''}
        </div>
        <div class="task-progress-track"><div class="task-progress-fill" style="width:${t.progress}%"></div></div>
      </div>
      <div class="task-actions">
        <button class="icon-btn" data-action="start-timer" title="Start focus session" data-id="${t.id}">▶</button>
        <button class="icon-btn" data-action="delete-task" title="Delete" data-id="${t.id}">🗑</button>
      </div>
    </div>`;
  },

  renderBoard(list) {
    const cols = [['todo', 'To Do'], ['in-progress', 'In Progress'], ['done', 'Done']];
    $('#taskBoard').innerHTML = cols.map(([status, label]) => {
      const items = list.filter((t) => t.status === status);
      return `<div class="board-col" data-status="${status}">
        <div class="board-col-head"><span>${label}</span><span>${items.length}</span></div>
        ${items.map((t) => `
          <div class="board-card" draggable="true" data-id="${t.id}" data-action="open-task">
            <strong>${escapeHtml(t.title)}</strong>
            <div class="task-meta" style="margin-top:8px">
              <span class="chip ${PRIORITY_CLASS[t.priority]}">${t.priority}</span>
              ${t.dueDate ? `<span class="chip">📅 ${t.dueDate}</span>` : ''}
            </div>
          </div>`).join('') || '<p class="muted" style="font-size:.78rem">Drop tasks here</p>'}
      </div>`;
    }).join('');
    this.wireBoardDnd();
  },

  wireBoardDnd() {
    let draggedId = null;
    $$('.board-card', $('#taskBoard')).forEach((card) => {
      card.addEventListener('dragstart', () => { draggedId = card.dataset.id; card.classList.add('is-dragging'); });
      card.addEventListener('dragend', () => card.classList.remove('is-dragging'));
    });
    $$('.board-col', $('#taskBoard')).forEach((col) => {
      col.addEventListener('dragover', (e) => e.preventDefault());
      col.addEventListener('drop', (e) => {
        e.preventDefault();
        if (draggedId) { this.setStatus(draggedId, col.dataset.status); this.render(); }
      });
    });
  },

  openEditor(id, presetProjectId) {
    const existing = id ? S().tasks.find((t) => t.id === id) : null;
    const categories = Array.from(new Set([...this.categories(), 'General', 'Work', 'Personal', 'Learning']));
    const body = `
      <div class="form-row"><label>Title</label><input type="text" id="fTitle" value="${existing ? escapeHtml(existing.title) : ''}" placeholder="e.g. Design the onboarding flow"></div>
      <div class="form-row"><label>Description</label><textarea id="fDesc">${existing ? escapeHtml(existing.description) : ''}</textarea></div>
      <div class="form-row">
        <label>Priority</label>
        <div class="priority-picker" id="fPriorityPicker">
          ${['Critical', 'High', 'Medium', 'Low'].map((p) => `<button type="button" class="priority-opt ${((existing?.priority) || 'Medium') === p ? 'is-selected' : ''}" data-p="${p}">${p}</button>`).join('')}
        </div>
      </div>
      <div class="form-grid-2">
        <div class="form-row"><label>Category</label><input type="text" id="fCategory" list="categoryList" value="${existing ? escapeHtml(existing.category) : 'General'}"><datalist id="categoryList">${categories.map((c) => `<option value="${escapeHtml(c)}">`).join('')}</datalist></div>
        <div class="form-row"><label>Due date</label><input type="date" id="fDue" value="${existing?.dueDate || ''}"></div>
      </div>
      <div class="form-grid-2">
        <div class="form-row"><label>Estimated duration (min)</label><input type="number" id="fEst" value="${existing?.estDuration || 30}" min="5" step="5"></div>
        <div class="form-row"><label>Recurring</label><select id="fRecurring">
          ${['none', 'daily', 'weekly', 'monthly'].map((r) => `<option value="${r}" ${existing?.recurring === r ? 'selected' : ''}>${r[0].toUpperCase() + r.slice(1)}</option>`).join('')}
        </select></div>
      </div>
      <div class="form-row"><label>Tags (Enter to add)</label>
        <div class="tag-input-wrap" id="fTagWrap">
          ${(existing?.tags || []).map((t) => tagPillHTML(t)).join('')}
          <input type="text" id="fTagInput" placeholder="Add tag…">
        </div>
      </div>
      <div class="form-row"><label>Color label</label>
        <div class="color-picker" id="fColorPicker">
          ${['', '#ff6b6b', '#ffa94d', '#ffd43b', '#69db7c', '#4dabf7', '#9775fa', '#f783ac'].map((c) => `<button type="button" class="color-opt ${(existing?.color || '') === c ? 'is-selected' : ''}" data-c="${c}" style="background:${c || 'transparent'}; ${!c ? 'border:2px dashed var(--glass-border)' : ''}"></button>`).join('')}
        </div>
      </div>
      <div class="form-row"><label>Subtasks</label>
        <div class="subtask-list" id="fSubtaskList">
          ${(existing?.subtasks || []).map((s) => subtaskRowHTML(s)).join('')}
        </div>
        <button type="button" class="btn btn-ghost btn-sm" id="fAddSubtask">+ Add subtask</button>
      </div>
      <div class="form-row"><label>Notes</label><textarea id="fNotes" placeholder="Any extra context…">${existing?.notes || ''}</textarea></div>
      <div class="ai-suggest-box" id="fAiSuggest">✦ AI: suggest priority & due date from title</div>
    `;
    const actions = `<button class="btn btn-ghost" id="fCancel">Cancel</button><button class="btn btn-primary" id="fSave">${existing ? 'Save changes' : 'Create task'}</button>`;
    const root = Modal.open(existing ? 'Edit task' : 'New task', body, actions);

    let selectedPriority = existing?.priority || 'Medium';
    let selectedColor = existing?.color || '';
    let tags = [...(existing?.tags || [])];
    let subtasks = [...(existing?.subtasks || [])];

    $$('.priority-opt', root).forEach((btn) => btn.addEventListener('click', () => { selectedPriority = btn.dataset.p; $$('.priority-opt', root).forEach((b) => b.classList.toggle('is-selected', b === btn)); }));
    $$('.color-opt', root).forEach((btn) => btn.addEventListener('click', () => { selectedColor = btn.dataset.c; $$('.color-opt', root).forEach((b) => b.classList.toggle('is-selected', b === btn)); }));

    const tagInput = $('#fTagInput', root);
    tagInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && tagInput.value.trim()) {
        e.preventDefault();
        tags.push(tagInput.value.trim());
        tagInput.insertAdjacentHTML('beforebegin', tagPillHTML(tagInput.value.trim()));
        tagInput.value = '';
      }
    });
    $('#fTagWrap', root).addEventListener('click', (e) => {
      const rm = e.target.closest('[data-remove-tag]');
      if (rm) { tags = tags.filter((t) => t !== rm.dataset.removeTag); rm.closest('.tag-pill').remove(); }
    });

    const renderSubtasks = () => { $('#fSubtaskList', root).innerHTML = subtasks.map((s) => subtaskRowHTML(s)).join(''); };
    $('#fAddSubtask', root).addEventListener('click', () => { subtasks.push({ id: uid(), title: '', done: false }); renderSubtasks(); });
    $('#fSubtaskList', root).addEventListener('click', (e) => {
      const rm = e.target.closest('[data-remove-sub]');
      if (rm) { subtasks = subtasks.filter((s) => s.id !== rm.dataset.removeSub); renderSubtasks(); }
    });
    $('#fSubtaskList', root).addEventListener('input', (e) => {
      if (e.target.matches('[data-sub-title]')) { const s = subtasks.find((x) => x.id === e.target.dataset.subTitle); if (s) s.title = e.target.value; }
    });
    $('#fSubtaskList', root).addEventListener('change', (e) => {
      if (e.target.matches('[data-sub-check]')) { const s = subtasks.find((x) => x.id === e.target.dataset.subCheck); if (s) s.done = e.target.checked; }
    });

    $('#fAiSuggest', root).addEventListener('click', () => {
      const sug = this.suggest($('#fTitle', root).value, $('#fDesc', root).value);
      selectedPriority = sug.priority;
      $$('.priority-opt', root).forEach((b) => b.classList.toggle('is-selected', b.dataset.p === sug.priority));
      $('#fDue', root).value = sug.dueDate;
      Toast.show(`Suggested ${sug.priority} priority, due ${sug.dueDate}`, 'info', '✦');
    });

    $('#fCancel', root).addEventListener('click', Modal.close);
    $('#fSave', root).addEventListener('click', () => {
      const title = $('#fTitle', root).value.trim();
      if (!title) { Toast.show('Please give the task a title.', 'error'); return; }
      const data = {
        title, description: $('#fDesc', root).value.trim(), priority: selectedPriority,
        category: $('#fCategory', root).value.trim() || 'General', dueDate: $('#fDue', root).value,
        estDuration: $('#fEst', root).value, recurring: $('#fRecurring', root).value,
        tags, color: selectedColor, subtasks: subtasks.filter((s) => s.title.trim()),
        notes: $('#fNotes', root).value.trim(),
      };
      if (presetProjectId) data.projectId = presetProjectId;
      if (existing) this.update(existing.id, data); else this.create(data);
      Modal.close();
      this.render();
      DashboardManager.render();
      if (presetProjectId) ProjectManager.openDetail(presetProjectId);
    });
  },

  init() {
    $('#newTaskBtn').addEventListener('click', () => this.openEditor());
    $('#taskStatusFilter').addEventListener('click', (e) => { const b = e.target.closest('.segmented-btn'); if (!b) return; $$('.segmented-btn', $('#taskStatusFilter')).forEach((x) => x.classList.toggle('is-active', x === b)); this.filters.status = b.dataset.status; this.render(); });
    $('#taskPriorityFilter').addEventListener('change', (e) => { this.filters.priority = e.target.value; this.render(); });
    $('#taskCategoryFilter').addEventListener('change', (e) => { this.filters.category = e.target.value; this.render(); });
    $('#taskSort').addEventListener('change', (e) => { this.filters.sort = e.target.value; this.render(); });
    $('.view-toggle', $('#view-tasks')).addEventListener('click', (e) => {
      const b = e.target.closest('[data-tasklayout]'); if (!b) return;
      this.layout = b.dataset.tasklayout;
      $$('[data-tasklayout]', $('#view-tasks')).forEach((x) => x.classList.toggle('is-active', x === b));
      this.render();
    });
    $('#taskList').addEventListener('click', (e) => this.handleListClick(e));
    $('#taskBoard').addEventListener('click', (e) => this.handleListClick(e));
    Router.register('tasks', () => this.render());
  },

  handleListClick(e) {
    const idBtn = e.target.closest('[data-action]');
    if (!idBtn) return;
    const { action, id } = idBtn.dataset;
    if (action === 'toggle-done') { this.setStatus(id, S().tasks.find((t) => t.id === id).status === 'done' ? 'todo' : 'done'); this.render(); DashboardManager.render(); }
    else if (action === 'delete-task') { if (confirm('Delete this task?')) { this.remove(id); this.render(); DashboardManager.render(); } }
    else if (action === 'open-task') this.openEditor(id);
    else if (action === 'start-timer') WorkTracker.start(id);
  },
};

function tagPillHTML(t) { return `<span class="tag-pill">#${escapeHtml(t)}<button type="button" data-remove-tag="${escapeHtml(t)}">✕</button></span>`; }
function subtaskRowHTML(s) { return `<div class="subtask-row"><input type="checkbox" ${s.done ? 'checked' : ''} data-sub-check="${s.id}"><input type="text" value="${escapeHtml(s.title)}" placeholder="Subtask…" data-sub-title="${s.id}"><button type="button" class="icon-btn" data-remove-sub="${s.id}">✕</button></div>`; }
function emptyState(icon, title, sub) { return `<div class="empty-state"><div class="empty-state-icon">${icon}</div><h3>${title}</h3><p class="muted">${sub}</p></div>`; }

/* ============================================================
   8. WORK TRACKER  (start/pause/resume/complete focus sessions)
   ============================================================ */
const WorkTracker = {
  intervalId: null,

  get timer() { return S().activeTimer; },

  start(taskId) {
    if (this.timer) { Toast.show('A session is already running. Finish it first.', 'error'); return; }
    const task = S().tasks.find((t) => t.id === taskId);
    S().activeTimer = { taskId: taskId || null, projectId: task?.projectId || '', start: Date.now(), accumActiveMs: 0, accumBreakMs: 0, state: 'running', pausedAt: null };
    if (task && task.status === 'todo') this.wireStatus(task);
    persist();
    Activity.log('session', `Started focus session${task ? ` on "${task.title}"` : ''}`, '▶');
    this.tickLoop();
    Bus.emit('timer:changed');
  },
  wireStatus(task) { TaskManager.setStatus(task.id, 'in-progress'); },

  pause() {
    const t = this.timer; if (!t || t.state !== 'running') return;
    t.accumActiveMs += Date.now() - (t.resumedAt || t.start);
    t.state = 'paused'; t.pausedAt = Date.now();
    persist();
    Activity.log('session', 'Paused focus session', '⏸');
    Bus.emit('timer:changed');
  },
  resume() {
    const t = this.timer; if (!t || t.state !== 'paused') return;
    t.accumBreakMs += Date.now() - t.pausedAt;
    t.state = 'running'; t.resumedAt = Date.now();
    persist();
    Activity.log('session', 'Resumed focus session', '▶');
    Bus.emit('timer:changed');
  },
  complete() {
    const t = this.timer; if (!t) return;
    const now = Date.now();
    if (t.state === 'running') t.accumActiveMs += now - (t.resumedAt || t.start);
    else t.accumBreakMs += now - t.pausedAt;
    const session = { id: uid(), taskId: t.taskId, projectId: t.projectId, start: t.start, end: now, activeMs: t.accumActiveMs, breakMs: t.accumBreakMs };
    S().sessions.push(session);
    if (t.taskId) {
      const task = S().tasks.find((x) => x.id === t.taskId);
      if (task) task.actualMs = (task.actualMs || 0) + t.accumActiveMs;
    }
    S().activeTimer = null;
    persist();
    const mins = Math.round(t.accumActiveMs / 60000);
    Activity.log('session', `Completed a ${mins}m focus session`, '✓');
    Gamification.addXp(clamp(Math.round(mins / 5), 2, 25), 'focus session logged');
    Toast.show(`Session logged: ${formatDuration(t.accumActiveMs)} focused`, 'success');
    Bus.emit('timer:changed');
    DashboardManager.render();
    AnalyticsManager.invalidate();
  },

  tickLoop() {
    if (this.intervalId) return;
    this.intervalId = setInterval(() => {
      if (!this.timer) { clearInterval(this.intervalId); this.intervalId = null; this.renderChrome(); return; }
      this.renderChrome();
    }, 1000);
    this.renderChrome();
  },

  currentElapsed() {
    const t = this.timer; if (!t) return 0;
    if (t.state === 'running') return t.accumActiveMs + (Date.now() - (t.resumedAt || t.start));
    return t.accumActiveMs;
  },

  renderChrome() {
    const t = this.timer;
    const mini = $('#miniTimer');
    if (!t) { mini.hidden = true; return; }
    mini.hidden = false;
    const task = t.taskId ? S().tasks.find((x) => x.id === t.taskId) : null;
    $('#miniTimerLabel').textContent = task ? task.title : 'Focus session';
    $('#miniTimerTime').textContent = formatDuration(this.currentElapsed());
    Bus.emit('timer:tick');
  },

  init() {
    if (this.timer) this.tickLoop();
  },
};

/* ============================================================
   9. PROJECT MANAGER
   ============================================================ */
const KANBAN_COLS = [['todo', 'To Do'], ['in-progress', 'In Progress'], ['review', 'Review'], ['done', 'Done']];
const PROJECT_COLORS = ['#7c6cf6', '#4dabf7', '#69db7c', '#ffa94d', '#ff6b6b', '#f783ac'];

const ProjectManager = {
  activeId: null,

  create(data) {
    const p = { id: uid(), title: data.title, description: data.description || '', color: data.color || PROJECT_COLORS[S().projects.length % PROJECT_COLORS.length], deadline: data.deadline || '', milestones: [], createdAt: Date.now() };
    S().projects.push(p);
    persist();
    Activity.log('project', `Created project "${p.title}"`, '◆');
    Gamification.addXp(8, 'new project started');
    Bus.emit('projects:changed');
    return p;
  },
  remove(id) { S().projects = S().projects.filter((p) => p.id !== id); S().tasks.forEach((t) => { if (t.projectId === id) t.projectId = ''; }); persist(); Bus.emit('projects:changed'); },
  addMilestone(id, title, due) { const p = S().projects.find((x) => x.id === id); p.milestones.push({ id: uid(), title, due, done: false }); persist(); Bus.emit('projects:changed'); },
  toggleMilestone(pid, mid) { const p = S().projects.find((x) => x.id === pid); const m = p.milestones.find((x) => x.id === mid); m.done = !m.done; persist(); Bus.emit('projects:changed'); },

  progress(p) {
    const tasks = S().tasks.filter((t) => t.projectId === p.id);
    if (!tasks.length) return 0;
    return Math.round((tasks.filter((t) => t.status === 'done').length / tasks.length) * 100);
  },
  hours(p) {
    return S().sessions.filter((s) => s.projectId === p.id).reduce((a, s) => a + s.activeMs, 0);
  },

  render() {
    const grid = $('#projectGrid');
    const projects = S().projects;
    if (!projects.length) { grid.innerHTML = emptyState('◆', 'No projects yet', 'Create a project to group related tasks.'); }
    else {
      grid.innerHTML = projects.map((p) => {
        const pct = this.progress(p);
        const circumference = 2 * Math.PI * 20;
        const offset = circumference - (pct / 100) * circumference;
        return `
        <div class="project-card card" data-id="${p.id}">
          <div class="project-card-top">
            <span class="project-color-dot" style="background:${p.color}"></span>
            <svg class="project-progress-ring" viewBox="0 0 48 48">
              <circle cx="24" cy="24" r="20" fill="none" stroke="hsl(var(--accent-h) 30% 50% / .15)" stroke-width="5"/>
              <circle cx="24" cy="24" r="20" fill="none" stroke="${p.color}" stroke-width="5" stroke-linecap="round" stroke-dasharray="${circumference}" stroke-dashoffset="${offset}" transform="rotate(-90 24 24)"/>
            </svg>
          </div>
          <div class="project-title">${escapeHtml(p.title)}</div>
          <p class="muted" style="font-size:.8rem">${escapeHtml(p.description || 'No description')}</p>
          <div class="task-meta" style="margin-top:10px">
            <span class="chip">${pct}% complete</span>
            ${p.deadline ? `<span class="chip">📅 ${p.deadline}</span>` : ''}
            <span class="chip">⏱ ${formatHoursShort(this.hours(p))}</span>
          </div>
          ${p.milestones.length ? `<div class="project-milestones">${p.milestones.slice(0, 3).map((m) => `<div class="milestone-item ${m.done ? 'is-done' : ''}">${m.done ? '☑' : '☐'} ${escapeHtml(m.title)}</div>`).join('')}</div>` : ''}
        </div>`;
      }).join('');
    }
    $$('.project-card', grid).forEach((c) => c.addEventListener('click', () => this.openDetail(c.dataset.id)));
  },

  openDetail(id) {
    this.activeId = id;
    const p = S().projects.find((x) => x.id === id);
    if (!p) return;
    $('#projectGrid').hidden = true;
    $('#projectDetail').hidden = false;
    const tasksInProject = S().tasks.filter((t) => t.projectId === id);
    $('#projectDetailBody').innerHTML = `
      <div class="view-head">
        <div><h1>${escapeHtml(p.title)}</h1><p class="view-sub">${escapeHtml(p.description || '')}</p></div>
        <div style="display:flex;gap:8px">
          <button class="btn btn-ghost btn-sm" id="pAddMilestone">+ Milestone</button>
          <button class="btn btn-ghost btn-sm" id="pAddTask">+ Task</button>
          <button class="btn btn-danger btn-sm" id="pDelete">Delete project</button>
        </div>
      </div>
      <div class="analytics-stats">
        <div class="card"><div class="stat-label">Progress</div><div class="stat-big">${this.progress(p)}%</div></div>
        <div class="card"><div class="stat-label">Hours logged</div><div class="stat-big">${formatHoursShort(this.hours(p))}</div></div>
        <div class="card"><div class="stat-label">Tasks</div><div class="stat-big">${tasksInProject.length}</div></div>
        <div class="card"><div class="stat-label">Deadline</div><div class="stat-big" style="font-size:1.2rem">${p.deadline || '—'}</div></div>
      </div>
      <div class="card">
        <h3>Milestones</h3>
        <div class="project-milestones" id="pMilestoneList" style="margin-top:10px">
          ${p.milestones.map((m) => `<div class="milestone-item ${m.done ? 'is-done' : ''}" data-mid="${m.id}" style="cursor:pointer">${m.done ? '☑' : '☐'} ${escapeHtml(m.title)} ${m.due ? `<span class="muted">— ${m.due}</span>` : ''}</div>`).join('') || '<p class="muted">No milestones yet.</p>'}
        </div>
      </div>
      <h3 style="margin:20px 0 10px">Kanban board</h3>
      <div class="kanban" id="pKanban">
        ${KANBAN_COLS.map(([status, label]) => `
          <div class="board-col" data-status="${status}">
            <div class="board-col-head"><span>${label}</span><span>${tasksInProject.filter((t) => (status === 'review' ? t.reviewFlag : t.status === status && !t.reviewFlag)).length}</span></div>
            ${tasksInProject.filter((t) => (status === 'review' ? t.reviewFlag : t.status === status && !t.reviewFlag)).map((t) => `<div class="board-card" draggable="true" data-id="${t.id}"><strong>${escapeHtml(t.title)}</strong><div class="task-meta" style="margin-top:6px"><span class="chip ${PRIORITY_CLASS[t.priority]}">${t.priority}</span></div></div>`).join('')}
          </div>`).join('')}
      </div>
    `;
    $('#pMilestoneList').addEventListener('click', (e) => { const m = e.target.closest('[data-mid]'); if (m) { this.toggleMilestone(id, m.dataset.mid); this.openDetail(id); } });
    $('#pAddMilestone').addEventListener('click', () => {
      const title = prompt('Milestone name:'); if (!title) return;
      const due = prompt('Due date (YYYY-MM-DD), optional:') || '';
      this.addMilestone(id, title, due);
      this.openDetail(id);
    });
    $('#pAddTask').addEventListener('click', () => { TaskManager.openEditor(null, id); });
    $('#pDelete').addEventListener('click', () => { if (confirm('Delete this project? Tasks will be kept but unlinked.')) { this.remove(id); this.backToList(); } });
    this.wireKanbanDnd(id);
  },

  wireKanbanDnd(projectId) {
    let draggedId = null;
    $$('.board-card', $('#pKanban')).forEach((card) => {
      card.addEventListener('dragstart', () => { draggedId = card.dataset.id; card.classList.add('is-dragging'); });
      card.addEventListener('dragend', () => card.classList.remove('is-dragging'));
    });
    $$('.board-col', $('#pKanban')).forEach((col) => {
      col.addEventListener('dragover', (e) => e.preventDefault());
      col.addEventListener('drop', (e) => {
        e.preventDefault();
        if (!draggedId) return;
        const task = S().tasks.find((t) => t.id === draggedId);
        if (col.dataset.status === 'review') { task.reviewFlag = true; }
        else { task.reviewFlag = false; TaskManager.setStatus(draggedId, col.dataset.status); }
        persist();
        this.openDetail(projectId);
      });
    });
  },

  backToList() { $('#projectGrid').hidden = false; $('#projectDetail').hidden = true; this.render(); },

  openEditor() {
    const body = `
      <div class="form-row"><label>Project name</label><input type="text" id="qTitle" placeholder="e.g. Website Redesign"></div>
      <div class="form-row"><label>Description</label><textarea id="qDesc"></textarea></div>
      <div class="form-grid-2">
        <div class="form-row"><label>Deadline</label><input type="date" id="qDeadline"></div>
        <div class="form-row"><label>Color</label>
          <div class="color-picker" id="qColorPicker">${PROJECT_COLORS.map((c, i) => `<button type="button" class="color-opt ${i === 0 ? 'is-selected' : ''}" data-c="${c}" style="background:${c}"></button>`).join('')}</div>
        </div>
      </div>`;
    const actions = `<button class="btn btn-ghost" id="qCancel">Cancel</button><button class="btn btn-primary" id="qSave">Create project</button>`;
    const root = Modal.open('New project', body, actions);
    let color = PROJECT_COLORS[0];
    $$('.color-opt', root).forEach((b) => b.addEventListener('click', () => { color = b.dataset.c; $$('.color-opt', root).forEach((x) => x.classList.toggle('is-selected', x === b)); }));
    $('#qCancel', root).addEventListener('click', Modal.close);
    $('#qSave', root).addEventListener('click', () => {
      const title = $('#qTitle', root).value.trim();
      if (!title) { Toast.show('Give your project a name.', 'error'); return; }
      this.create({ title, description: $('#qDesc', root).value.trim(), deadline: $('#qDeadline', root).value, color });
      Modal.close();
      this.render();
    });
  },

  init() {
    $('#newProjectBtn').addEventListener('click', () => this.openEditor());
    $('#backToProjects').addEventListener('click', () => this.backToList());
    Router.register('projects', () => this.render());
  },
};

/* ============================================================
   10. CALENDAR MANAGER
   ============================================================ */
const CalendarManager = {
  mode: 'month',
  cursor: new Date(),

  create(data) { S().events.push({ id: uid(), ...data }); persist(); Activity.log('event', `Added event "${data.title}"`, '▦'); Bus.emit('events:changed'); },
  remove(id) { S().events = S().events.filter((e) => e.id !== id); persist(); Bus.emit('events:changed'); },

  eventsOn(dateStr) {
    return S().events.filter((e) => {
      if (e.date === dateStr) return true;
      if (e.recurring === 'weekly') {
        const start = new Date(e.date);
        const target = new Date(dateStr);
        return target >= start && target.getDay() === start.getDay();
      }
      return false;
    });
  },

  render() {
    $('#calLabel').textContent = this.mode === 'month' ? this.cursor.toLocaleDateString([], { month: 'long', year: 'numeric' })
      : this.mode === 'week' ? `Week of ${dateKey(this.weekStart())}`
      : this.mode === 'day' ? this.cursor.toLocaleDateString([], { weekday: 'long', month: 'long', day: 'numeric' })
      : 'Upcoming agenda';
    const body = $('#calendarBody');
    if (this.mode === 'month') body.innerHTML = this.monthHTML();
    else if (this.mode === 'week') body.innerHTML = this.weekHTML();
    else if (this.mode === 'day') body.innerHTML = this.dayHTML(this.cursor);
    else body.innerHTML = this.agendaHTML();
    $$('.cal-day[data-date]', body).forEach((el) => el.addEventListener('click', () => this.openEditorFor(el.dataset.date)));
  },

  weekStart() { const d = new Date(this.cursor); const dow = d.getDay(); const start = (dow - S().settings.weekStart + 7) % 7; return addDays(d, -start); },

  monthHTML() {
    const y = this.cursor.getFullYear(), m = this.cursor.getMonth();
    const first = new Date(y, m, 1);
    const startOffset = (first.getDay() - S().settings.weekStart + 7) % 7;
    const gridStart = addDays(first, -startOffset);
    const todayKey = dateKey(new Date());
    const dowNames = Array.from({ length: 7 }).map((_, i) => new Date(2023, 0, i + 1 + S().settings.weekStart).toLocaleDateString([], { weekday: 'short' }));
    let cells = '';
    for (let i = 0; i < 42; i++) {
      const d = addDays(gridStart, i);
      const key = dateKey(d);
      const outside = d.getMonth() !== m;
      const evs = this.eventsOn(key);
      cells += `<div class="cal-day ${key === todayKey ? 'is-today' : ''} ${outside ? 'is-outside' : ''}" data-date="${key}">
        <div class="cal-day-num">${d.getDate()}</div>
        ${evs.slice(0, 3).map((e) => `<div class="cal-event-pill">${escapeHtml(e.title)}</div>`).join('')}
        ${evs.length > 3 ? `<div class="muted" style="font-size:.65rem">+${evs.length - 3} more</div>` : ''}
      </div>`;
    }
    return `<div class="cal-month-grid">${dowNames.map((d) => `<div class="cal-dow">${d}</div>`).join('')}${cells}</div>`;
  },

  weekHTML() {
    const start = this.weekStart();
    const days = Array.from({ length: 7 }).map((_, i) => addDays(start, i));
    const todayKey = dateKey(new Date());
    return `<div class="cal-month-grid">${days.map((d) => {
      const key = dateKey(d);
      const evs = this.eventsOn(key);
      return `<div class="cal-day ${key === todayKey ? 'is-today' : ''}" data-date="${key}" style="min-height:220px">
        <div class="cal-day-num">${d.toLocaleDateString([], { weekday: 'short' })} ${d.getDate()}</div>
        ${evs.map((e) => `<div class="cal-event-pill">${e.time ? e.time + ' — ' : ''}${escapeHtml(e.title)}</div>`).join('')}
      </div>`;
    }).join('')}</div>`;
  },

  dayHTML(d) {
    const key = dateKey(d);
    const evs = this.eventsOn(key).sort((a, b) => (a.time || '').localeCompare(b.time || ''));
    if (!evs.length) return emptyState('▦', 'Nothing scheduled', 'Click "New Event" to add something to this day.');
    return `<div class="cal-agenda-list">${evs.map((e) => `<div class="cal-agenda-item"><strong>${e.time || 'All day'}</strong><div><strong>${escapeHtml(e.title)}</strong>${e.notes ? `<p class="muted">${escapeHtml(e.notes)}</p>` : ''}</div></div>`).join('')}</div>`;
  },

  agendaHTML() {
    const upcoming = S().events.filter((e) => e.date >= dateKey(new Date())).sort((a, b) => a.date.localeCompare(b.date) || (a.time || '').localeCompare(b.time || ''));
    if (!upcoming.length) return emptyState('▦', 'No upcoming events', 'Your agenda is clear.');
    return upcoming.map((e) => `<div class="cal-agenda-item"><strong>${e.date}${e.time ? ' · ' + e.time : ''}</strong><div><strong>${escapeHtml(e.title)}</strong>${e.notes ? `<p class="muted">${escapeHtml(e.notes)}</p>` : ''}${e.recurring !== 'none' ? `<span class="chip">🔁 ${e.recurring}</span>` : ''}</div><button class="icon-btn" data-remove-event="${e.id}">🗑</button></div>`).join('');
  },

  openEditorFor(dateStr) { this.openEditor(dateStr); },

  openEditor(prefillDate) {
    const body = `
      <div class="form-row"><label>Event title</label><input type="text" id="eTitle" placeholder="e.g. Team sync"></div>
      <div class="form-grid-2">
        <div class="form-row"><label>Date</label><input type="date" id="eDate" value="${prefillDate || dateKey(new Date())}"></div>
        <div class="form-row"><label>Time</label><input type="time" id="eTime"></div>
      </div>
      <div class="form-row"><label>Repeat</label><select id="eRecur"><option value="none">Does not repeat</option><option value="weekly">Weekly</option></select></div>
      <div class="form-row"><label>Notes</label><textarea id="eNotes"></textarea></div>
      <div class="form-row"><label>Reminder</label><label class="switch"><input type="checkbox" id="eRemind" checked><span class="switch-track"></span></label></div>
    `;
    const actions = `<button class="btn btn-ghost" id="eCancel">Cancel</button><button class="btn btn-primary" id="eSave">Save event</button>`;
    const root = Modal.open('New event', body, actions);
    $('#eCancel', root).addEventListener('click', Modal.close);
    $('#eSave', root).addEventListener('click', () => {
      const title = $('#eTitle', root).value.trim();
      if (!title) { Toast.show('Please name the event.', 'error'); return; }
      this.create({ title, date: $('#eDate', root).value, time: $('#eTime', root).value, recurring: $('#eRecur', root).value, notes: $('#eNotes', root).value.trim(), remind: $('#eRemind', root).checked });
      Modal.close();
      this.render();
    });
  },

  init() {
    $('#newEventBtn').addEventListener('click', () => this.openEditor());
    $('#calPrevBtn').addEventListener('click', () => { this.step(-1); });
    $('#calNextBtn').addEventListener('click', () => { this.step(1); });
    $('#calTodayBtn').addEventListener('click', () => { this.cursor = new Date(); this.render(); });
    $('#calModeSwitch').addEventListener('click', (e) => { const b = e.target.closest('.segmented-btn'); if (!b) return; this.mode = b.dataset.mode; $$('.segmented-btn', $('#calModeSwitch')).forEach((x) => x.classList.toggle('is-active', x === b)); this.render(); });
    $('#calendarBody').addEventListener('click', (e) => { const rm = e.target.closest('[data-remove-event]'); if (rm) { this.remove(rm.dataset.removeEvent); this.render(); } });
    Router.register('calendar', () => this.render());
  },
  step(dir) {
    if (this.mode === 'month') this.cursor = new Date(this.cursor.getFullYear(), this.cursor.getMonth() + dir, 1);
    else if (this.mode === 'week') this.cursor = addDays(this.cursor, 7 * dir);
    else this.cursor = addDays(this.cursor, dir);
    this.render();
  },
};

/* ============================================================
   11. HABIT MANAGER
   ============================================================ */
const HabitManager = {
  create(data) { S().habits.push({ id: uid(), name: data.name, targetDays: data.targetDays || [0, 1, 2, 3, 4, 5, 6], color: data.color || '#7c6cf6', log: {}, createdAt: Date.now() }); persist(); Activity.log('habit', `Created habit "${data.name}"`, '⟲'); Gamification.addXp(5, 'new habit tracked'); Bus.emit('habits:changed'); },
  remove(id) { S().habits = S().habits.filter((h) => h.id !== id); persist(); Bus.emit('habits:changed'); },
  toggleToday(id) {
    const h = S().habits.find((x) => x.id === id);
    const key = dateKey(new Date());
    const wasDone = !!h.log[key];
    if (wasDone) delete h.log[key]; else h.log[key] = true;
    persist();
    if (!wasDone) {
      Activity.log('habit', `Checked off habit "${h.name}"`, '✓');
      Gamification.addXp(4, 'habit completed');
    }
    Bus.emit('habits:changed');
  },
  completionRate(h, days = 30) {
    let done = 0;
    for (let i = 0; i < days; i++) if (h.log[dateKey(addDays(new Date(), -i))]) done++;
    return Math.round((done / days) * 100);
  },

  render() {
    const list = $('#habitList');
    const habits = S().habits;
    if (!habits.length) { list.innerHTML = emptyState('⟲', 'No habits yet', 'Small daily actions compound. Add your first habit.'); return; }
    const todayKey = dateKey(new Date());
    list.innerHTML = habits.map((h) => {
      const streak = computeStreak(h);
      const rate = this.completionRate(h);
      const mini = Array.from({ length: 14 }).map((_, i) => {
        const key = dateKey(addDays(new Date(), -(13 - i)));
        return `<span style="${h.log[key] ? `background:${h.color}` : ''}" title="${key}"></span>`;
      }).join('');
      return `<div class="habit-item card" data-id="${h.id}">
        <button class="habit-check ${h.log[todayKey] ? 'is-done' : ''}" data-action="toggle-habit" data-id="${h.id}" style="${h.log[todayKey] ? `background:${h.color};border-color:${h.color}` : ''}">${h.log[todayKey] ? '✓' : ''}</button>
        <div class="habit-info">
          <div class="habit-name">${escapeHtml(h.name)}</div>
          <div class="habit-streak">🔥 ${streak.current}-day streak · best ${streak.longest} · ${rate}% (30d)</div>
        </div>
        <div class="habit-mini-heat">${mini}</div>
        <button class="icon-btn" data-action="delete-habit" data-id="${h.id}">🗑</button>
      </div>`;
    }).join('');
  },

  openEditor() {
    const body = `<div class="form-row"><label>Habit name</label><input type="text" id="hName" placeholder="e.g. Read for 20 minutes"></div>
      <div class="form-row"><label>Color</label><div class="color-picker" id="hColorPicker">${PROJECT_COLORS.map((c, i) => `<button type="button" class="color-opt ${i === 0 ? 'is-selected' : ''}" data-c="${c}" style="background:${c}"></button>`).join('')}</div></div>`;
    const actions = `<button class="btn btn-ghost" id="hCancel">Cancel</button><button class="btn btn-primary" id="hSave">Create habit</button>`;
    const root = Modal.open('New habit', body, actions);
    let color = PROJECT_COLORS[0];
    $$('.color-opt', root).forEach((b) => b.addEventListener('click', () => { color = b.dataset.c; $$('.color-opt', root).forEach((x) => x.classList.toggle('is-selected', x === b)); }));
    $('#hCancel', root).addEventListener('click', Modal.close);
    $('#hSave', root).addEventListener('click', () => {
      const name = $('#hName', root).value.trim();
      if (!name) { Toast.show('Name your habit.', 'error'); return; }
      this.create({ name, color });
      Modal.close(); this.render();
    });
  },

  init() {
    $('#newHabitBtn').addEventListener('click', () => this.openEditor());
    $('#habitList').addEventListener('click', (e) => {
      const btn = e.target.closest('[data-action]'); if (!btn) return;
      if (btn.dataset.action === 'toggle-habit') { this.toggleToday(btn.dataset.id); this.render(); DashboardManager.render(); }
      else if (btn.dataset.action === 'delete-habit') { if (confirm('Delete this habit?')) { this.remove(btn.dataset.id); this.render(); } }
    });
    Router.register('habits', () => this.render());
  },
};

/* ============================================================
   12. JOURNAL + MOOD MANAGER
   ============================================================ */
const JournalManager = {
  draftImages: [], draftVoiceNotes: [], selectedMood: null, editingId: null,

  create(entry) { S().journalEntries.unshift(entry); persist(); Activity.log('journal', `Wrote journal entry "${entry.title || 'Untitled'}"`, '✎'); Gamification.addXp(6, 'journal entry saved'); Bus.emit('journal:changed'); },
  update(id, patch) { const e = S().journalEntries.find((x) => x.id === id); Object.assign(e, patch); persist(); Bus.emit('journal:changed'); },
  remove(id) { S().journalEntries = S().journalEntries.filter((e) => e.id !== id); persist(); Bus.emit('journal:changed'); },

  resetEditor() {
    this.editingId = null; this.draftImages = []; this.draftVoiceNotes = []; this.selectedMood = null;
    $('#journalTitle').value = '';
    $('#journalContent').innerHTML = '';
    $('#journalDate').textContent = new Date().toLocaleDateString([], { weekday: 'long', month: 'long', day: 'numeric' });
    $$('.mood-btn', $('#moodPicker')).forEach((b) => b.classList.remove('is-selected'));
    $('#voiceNotesList').innerHTML = '';
  },

  loadEntry(id) {
    const e = S().journalEntries.find((x) => x.id === id);
    if (!e) return;
    this.editingId = id;
    $('#journalTitle').value = e.title || '';
    $('#journalContent').innerHTML = e.contentHTML || '';
    $('#journalDate').textContent = new Date(e.createdAt).toLocaleDateString([], { weekday: 'long', month: 'long', day: 'numeric' });
    this.selectedMood = e.mood || null;
    $$('.mood-btn', $('#moodPicker')).forEach((b) => b.classList.toggle('is-selected', Number(b.dataset.mood) === e.mood));
    this.draftVoiceNotes = e.voiceNotes || [];
    this.renderVoiceNotes();
  },

  renderVoiceNotes() {
    $('#voiceNotesList').innerHTML = this.draftVoiceNotes.map((v, i) => `<div class="voice-note-item">🎙 Voice note ${i + 1} (${v.duration}s) <audio controls src="${v.data}" style="height:28px"></audio></div>`).join('');
  },

  save() {
    const title = $('#journalTitle').value.trim();
    const contentHTML = $('#journalContent').innerHTML;
    if (!title && !contentHTML.trim()) { Toast.show('Write something before saving.', 'error'); return; }
    const payload = { title, contentHTML, mood: this.selectedMood, voiceNotes: this.draftVoiceNotes };
    if (this.editingId) { this.update(this.editingId, payload); Toast.show('Entry updated.', 'success'); }
    else { this.create({ id: uid(), createdAt: Date.now(), dateKey: dateKey(new Date()), ...payload }); Toast.show('Entry saved.', 'success'); }
    this.resetEditor();
    this.render();
    MoodManager.render();
  },

  render() {
    const list = $('#entryList');
    const entries = S().journalEntries;
    list.innerHTML = entries.length ? entries.map((e) => `<div class="entry-item" data-id="${e.id}">
        <strong>${escapeHtml(e.title || 'Untitled')}</strong>
        <div class="muted" style="font-size:.72rem">${new Date(e.createdAt).toLocaleDateString()} ${e.mood ? MOOD_EMOJI[e.mood] : ''}</div>
      </div>`).join('') : '<p class="muted">No entries yet.</p>';
    $$('.entry-item', list).forEach((el) => el.addEventListener('click', () => this.loadEntry(el.dataset.id)));
  },

  init() {
    this.resetEditor();
    $('#newEntryBtn').addEventListener('click', () => this.resetEditor());
    $('#discardEntryBtn').addEventListener('click', () => this.resetEditor());
    $('#saveEntryBtn').addEventListener('click', () => this.save());
    $('#moodPicker').addEventListener('click', (e) => { const b = e.target.closest('.mood-btn'); if (!b) return; this.selectedMood = Number(b.dataset.mood); $$('.mood-btn', $('#moodPicker')).forEach((x) => x.classList.toggle('is-selected', x === b)); });
    $$('.rte-btn[data-cmd]').forEach((btn) => btn.addEventListener('click', () => {
      $('#journalContent').focus();
      document.execCommand(btn.dataset.cmd, false, btn.dataset.val || null);
    }));
    $('#journalImgInput').addEventListener('change', (e) => {
      const file = e.target.files[0]; if (!file) return;
      const reader = new FileReader();
      reader.onload = () => { document.execCommand('insertHTML', false, `<img src="${reader.result}">`); };
      reader.readAsDataURL(file);
      e.target.value = '';
    });
    this.wireVoiceRecording();
    Router.register('journal', () => { this.render(); MoodManager.render(); });
  },

  wireVoiceRecording() {
    let recorder = null; let chunks = []; let startTime = 0;
    const btn = $('#voiceNoteBtn');
    btn.addEventListener('click', async () => {
      if (!navigator.mediaDevices?.getUserMedia) { Toast.show('Voice recording is not supported in this browser.', 'error'); return; }
      if (recorder && recorder.state === 'recording') { recorder.stop(); return; }
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        recorder = new MediaRecorder(stream);
        chunks = []; startTime = Date.now();
        recorder.ondataavailable = (ev) => chunks.push(ev.data);
        recorder.onstop = () => {
          const blob = new Blob(chunks, { type: 'audio/webm' });
          const reader = new FileReader();
          reader.onload = () => {
            this.draftVoiceNotes.push({ data: reader.result, duration: Math.round((Date.now() - startTime) / 1000) });
            this.renderVoiceNotes();
          };
          reader.readAsDataURL(blob);
          stream.getTracks().forEach((t) => t.stop());
          btn.textContent = '🎙 Voice';
        };
        recorder.start();
        btn.textContent = '⏹ Stop';
        Toast.show('Recording… click again to stop.', 'info');
      } catch (err) { Toast.show('Microphone access denied.', 'error'); }
    });
  },
};

const MOOD_EMOJI = { 5: '😄', 4: '🙂', 3: '😐', 2: '🙁', 1: '😞' };

const MoodManager = {
  last7() {
    return Array.from({ length: 7 }).map((_, i) => {
      const key = dateKey(addDays(new Date(), -(6 - i)));
      const entries = S().journalEntries.filter((e) => e.dateKey === key && e.mood);
      const avg = entries.length ? entries.reduce((a, e) => a + e.mood, 0) / entries.length : null;
      return { key, avg };
    });
  },

  render() {
    const data = this.last7();
    const canvas = $('#moodTrendChart');
    ChartRenderer.line(canvas, data.map((d) => d.avg), { min: 1, max: 5, labels: data.map((d) => d.key.slice(5)), color: 'var(--accent)' });
    const known = data.filter((d) => d.avg !== null);
    let insight = 'Log a mood in your journal to see AI insights here.';
    if (known.length >= 2) {
      const trend = known[known.length - 1].avg - known[0].avg;
      insight = trend > 0.4 ? "Your mood has been trending upward this week — whatever you're doing, keep it up." : trend < -0.4 ? 'Your mood dipped a bit this week. Consider a lighter workload or a walk outside.' : 'Your mood has been fairly steady this week.';
    }
    $('#moodInsight').textContent = insight;
  },
};

/* ============================================================
   13. CHART RENDERER  (tiny canvas-2d chart helpers — no lib)
   ============================================================ */
const ChartRenderer = {
  _themeColor(varName) {
    return getComputedStyle(document.body).getPropertyValue(varName) || '#7c6cf6';
  },
  _resolveColor(c) {
    if (c && c.startsWith('var(')) return this._themeColor(c.slice(4, -1));
    return c || this._themeColor('--accent');
  },
  clear(ctx, w, h) { ctx.clearRect(0, 0, w, h); },

  bar(canvas, values, { labels = [], color = 'var(--accent)' } = {}) {
    const ctx = canvas.getContext('2d');
    const w = canvas.width, h = canvas.height;
    this.clear(ctx, w, h);
    const max = Math.max(1, ...values);
    const pad = 28;
    const bw = (w - pad * 2) / values.length;
    const c = this._resolveColor(color);
    ctx.fillStyle = c;
    ctx.strokeStyle = getComputedStyle(document.body).getPropertyValue('--text-2') || '#999';
    ctx.font = '11px system-ui';
    values.forEach((v, i) => {
      const bh = ((h - pad * 2) * v) / max;
      const x = pad + i * bw + bw * 0.18;
      const y = h - pad - bh;
      const grad = ctx.createLinearGradient(0, y, 0, h - pad);
      grad.addColorStop(0, c); grad.addColorStop(1, this._resolveColor('var(--accent-2)'));
      ctx.fillStyle = grad;
      roundRect(ctx, x, y, bw * 0.64, bh, 5);
      ctx.fill();
      ctx.fillStyle = getComputedStyle(document.body).getPropertyValue('--text-2') || '#999';
      ctx.textAlign = 'center';
      ctx.fillText(labels[i] || '', x + bw * 0.32, h - pad + 14);
    });
  },

  line(canvas, values, { min = 0, max = null, labels = [], color = 'var(--accent)' } = {}) {
    const ctx = canvas.getContext('2d');
    const w = canvas.width, h = canvas.height;
    this.clear(ctx, w, h);
    const known = values.filter((v) => v !== null && v !== undefined);
    const dmax = max ?? Math.max(1, ...known);
    const pad = 24;
    const c = this._resolveColor(color);
    ctx.strokeStyle = c; ctx.lineWidth = 2.5; ctx.lineJoin = 'round'; ctx.lineCap = 'round';
    ctx.beginPath();
    let started = false;
    const pts = [];
    values.forEach((v, i) => {
      const x = pad + (i * (w - pad * 2)) / (values.length - 1 || 1);
      if (v === null || v === undefined) { started = false; return; }
      const y = h - pad - ((v - min) / (dmax - min || 1)) * (h - pad * 2);
      pts.push([x, y]);
      if (!started) { ctx.moveTo(x, y); started = true; } else ctx.lineTo(x, y);
    });
    ctx.stroke();
    // gradient fill under line
    if (pts.length > 1) {
      ctx.lineTo(pts[pts.length - 1][0], h - pad);
      ctx.lineTo(pts[0][0], h - pad);
      ctx.closePath();
      const grad = ctx.createLinearGradient(0, 0, 0, h);
      grad.addColorStop(0, c + '55'); grad.addColorStop(1, c + '00');
      ctx.fillStyle = grad; ctx.globalAlpha = 0.5; ctx.fill(); ctx.globalAlpha = 1;
    }
    ctx.fillStyle = c;
    pts.forEach(([x, y]) => { ctx.beginPath(); ctx.arc(x, y, 3, 0, 7); ctx.fill(); });
    ctx.fillStyle = getComputedStyle(document.body).getPropertyValue('--text-2') || '#999';
    ctx.font = '10px system-ui'; ctx.textAlign = 'center';
    labels.forEach((l, i) => { const x = pad + (i * (w - pad * 2)) / (labels.length - 1 || 1); ctx.fillText(l, x, h - 6); });
  },

  donut(canvas, segments) { // segments: [{value,color,label}]
    const ctx = canvas.getContext('2d');
    const w = canvas.width, h = canvas.height;
    this.clear(ctx, w, h);
    const total = segments.reduce((a, s) => a + s.value, 0) || 1;
    const cx = w / 2, cy = h / 2, r = Math.min(w, h) / 2 - 10;
    let start = -Math.PI / 2;
    segments.forEach((s) => {
      const angle = (s.value / total) * Math.PI * 2;
      ctx.beginPath();
      ctx.moveTo(cx, cy);
      ctx.arc(cx, cy, r, start, start + angle);
      ctx.closePath();
      ctx.fillStyle = this._resolveColor(s.color);
      ctx.fill();
      start += angle;
    });
    ctx.globalCompositeOperation = 'destination-out';
    ctx.beginPath(); ctx.arc(cx, cy, r * 0.6, 0, 7); ctx.fill();
    ctx.globalCompositeOperation = 'source-over';
  },
};
function roundRect(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

/* ============================================================
   14. HEATMAP COMPONENT (GitHub-style contribution graph)
   ============================================================ */
const HeatmapComponent = {
  /** Returns activity intensity 0-4 for a given day, based on tasks done,
   *  habits checked, focus sessions and journal entries that day. */
  intensityFor(dateStr) {
    const s = S();
    let score = 0;
    score += s.tasks.filter((t) => t.status === 'done' && dateKey(new Date(t.createdAt)) === dateStr).length;
    score += s.habits.reduce((a, h) => a + (h.log[dateStr] ? 1 : 0), 0);
    score += s.sessions.filter((sess) => dateKey(new Date(sess.start)) === dateStr).length;
    score += s.journalEntries.filter((e) => e.dateKey === dateStr).length;
    if (score === 0) return 0;
    if (score === 1) return 1;
    if (score <= 3) return 2;
    if (score <= 5) return 3;
    return 4;
  },

  render(container, days = 365) {
    const today = startOfDay(new Date());
    const cells = [];
    for (let i = days - 1; i >= 0; i--) {
      const d = addDays(today, -i);
      const key = dateKey(d);
      const level = this.intensityFor(key);
      cells.push(`<div class="heatmap-cell" data-level="${level}" data-tip="${key}: ${level === 0 ? 'no activity' : `level ${level}`}"></div>`);
    }
    container.innerHTML = cells.join('');
  },
};

/* ============================================================
   15. ANALYTICS MANAGER
   ============================================================ */
const AnalyticsManager = {
  range: 'week',
  heatmapRange: 'yearly',
  _dirty: true,
  invalidate() { this._dirty = true; },

  rangeDays() { return { day: 1, week: 7, month: 30, year: 365 }[this.range]; },

  sessionsInRange() {
    const cutoff = addDays(new Date(), -this.rangeDays()).getTime();
    return S().sessions.filter((s) => s.start >= cutoff);
  },

  render() {
    const s = S();
    const sessions = this.sessionsInRange();
    const totalMs = sessions.reduce((a, x) => a + x.activeMs, 0);
    const days = this.rangeDays();
    const doneTasks = s.tasks.filter((t) => t.status === 'done').length;
    const avgPerTask = doneTasks ? s.tasks.filter((t) => t.status === 'done').reduce((a, t) => a + (t.actualMs || 0), 0) / doneTasks : 0;

    $('#analyticsStats').innerHTML = [
      ['Focus time', formatHoursShort(totalMs)],
      ['Sessions', sessions.length],
      ['Tasks completed', doneTasks],
      ['Avg / task', formatHoursShort(avgPerTask)],
      ['Level', `${s.gamification.level} · ${s.gamification.xp} XP`],
    ].map(([label, val]) => `<div class="card"><div class="stat-label">${label}</div><div class="stat-big" style="font-size:1.5rem">${val}</div></div>`).join('');

    // Working hours over range (bucketed by day, up to last 14 buckets for readability)
    const buckets = Math.min(days, 14);
    const step = Math.max(1, Math.floor(days / buckets));
    const hourVals = []; const hourLabels = [];
    for (let b = buckets - 1; b >= 0; b--) {
      const dayStart = addDays(new Date(), -(b * step));
      const key = dateKey(dayStart);
      const ms = s.sessions.filter((x) => dateKey(new Date(x.start)) === key).reduce((a, x) => a + x.activeMs, 0);
      hourVals.push(+(ms / 3.6e6).toFixed(2));
      hourLabels.push(key.slice(5));
    }
    ChartRenderer.bar($('#hoursChart'), hourVals, { labels: hourLabels, color: 'var(--accent)' });

    // Task completion trend
    const compVals = []; const compLabels = [];
    for (let b = buckets - 1; b >= 0; b--) {
      const key = dateKey(addDays(new Date(), -(b * step)));
      const count = s.tasks.filter((t) => t.status === 'done' && dateKey(new Date(t.createdAt)) === key).length;
      compVals.push(count); compLabels.push(key.slice(5));
    }
    ChartRenderer.line($('#completionChart'), compVals, { labels: compLabels, min: 0, color: 'var(--success)' });

    // Time distribution by category (donut)
    const byCategory = {};
    s.tasks.forEach((t) => { if (t.actualMs) byCategory[t.category] = (byCategory[t.category] || 0) + t.actualMs; });
    const catColors = ['var(--accent)', 'var(--accent-2)', 'var(--success)', 'var(--warning)', 'var(--low)', 'var(--high)'];
    const segs = Object.entries(byCategory).map(([label, value], i) => ({ label, value, color: catColors[i % catColors.length] }));
    if (!segs.length) segs.push({ label: 'No data', value: 1, color: 'var(--text-2)' });
    ChartRenderer.donut($('#distributionChart'), segs);

    // Habit consistency
    const habitVals = s.habits.map((h) => HabitManager.completionRate(h, days));
    const habitLabels = s.habits.map((h) => h.name.slice(0, 6));
    ChartRenderer.bar($('#habitChart'), habitVals.length ? habitVals : [0], { labels: habitLabels.length ? habitLabels : ['—'], color: 'var(--warning)' });

    HeatmapComponent.render($('#analyticsHeatmap'), this.heatmapRange === 'weekly' ? 7 : this.heatmapRange === 'monthly' ? 30 : 365);
    this._dirty = false;
  },

  init() {
    $('#analyticsRange').addEventListener('click', (e) => { const b = e.target.closest('.segmented-btn'); if (!b) return; this.range = b.dataset.range; $$('.segmented-btn', $('#analyticsRange')).forEach((x) => x.classList.toggle('is-active', x === b)); this.render(); });
    $('#heatmapRange').addEventListener('click', (e) => { const b = e.target.closest('.segmented-btn'); if (!b) return; this.heatmapRange = b.dataset.hrange; $$('.segmented-btn', $('#heatmapRange')).forEach((x) => x.classList.toggle('is-active', x === b)); this.render(); });
    Router.register('analytics', () => this.render());
  },
};

/* ============================================================
   16. AI COACH  (on-device heuristic insights)
   ============================================================ */
const CoachManager = {
  generate() {
    const s = S();
    const cards = [];

    // Best focus time of day
    if (s.sessions.length >= 3) {
      const byHour = {};
      s.sessions.forEach((sess) => { const h = new Date(sess.start).getHours(); byHour[h] = (byHour[h] || 0) + sess.activeMs; });
      const best = Object.entries(byHour).sort((a, b) => b[1] - a[1])[0];
      const hour = Number(best[0]);
      const label = hour < 12 ? `${hour || 12}AM` : `${hour === 12 ? 12 : hour - 12}PM`;
      cards.push({ icon: '🎯', title: 'Your peak focus window', body: `You tend to log the most focused time around ${label}. Try scheduling deep work then.` });
    } else {
      cards.push({ icon: '🎯', title: 'Not enough data yet', body: 'Log a few more focus sessions and I\'ll tell you your best time of day to work.' });
    }

    // Overdue tasks
    const overdue = s.tasks.filter((t) => t.status !== 'done' && t.dueDate && t.dueDate < dateKey(new Date()));
    if (overdue.length) cards.push({ icon: '⚠', title: `${overdue.length} overdue task${overdue.length > 1 ? 's' : ''}`, body: `"${overdue[0].title}"${overdue.length > 1 ? ` and ${overdue.length - 1} more` : ''} slipped past their due date. Consider re-scheduling or breaking them into smaller steps.` });
    else cards.push({ icon: '✅', title: 'Nothing overdue', body: "You're on top of every deadline — nice work." });

    // Habit consistency
    const weakHabit = s.habits.map((h) => ({ h, rate: HabitManager.completionRate(h, 14) })).sort((a, b) => a.rate - b.rate)[0];
    if (weakHabit) cards.push({ icon: '⟲', title: `"${weakHabit.h.name}" needs attention`, body: `You've completed it ${weakHabit.rate}% of the last 14 days. Try pairing it with something you already do daily.` });

    // Mood correlation
    const moodDays = s.journalEntries.filter((e) => e.mood);
    if (moodDays.length >= 3) {
      const highMoodMs = [];
      moodDays.forEach((e) => { const ms = s.sessions.filter((x) => dateKey(new Date(x.start)) === e.dateKey).reduce((a, x) => a + x.activeMs, 0); if (e.mood >= 4) highMoodMs.push(ms); });
      if (highMoodMs.length) {
        const avgHours = (highMoodMs.reduce((a, b) => a + b, 0) / highMoodMs.length / 3.6e6).toFixed(1);
        cards.push({ icon: '😊', title: 'Mood & focus link', body: `On days you felt good, you averaged ${avgHours}h of focused work. Protecting your mood may boost output.` });
      }
    }

    // Workload balance
    const inProgress = s.tasks.filter((t) => t.status === 'in-progress').length;
    if (inProgress > 5) cards.push({ icon: '🧠', title: 'You may be over-committing', body: `You have ${inProgress} tasks in progress at once. Consider focusing on 2–3 at a time for better throughput.` });

    // Streak encouragement
    const bestStreak = s.habits.map((h) => computeStreak(h).current).sort((a, b) => b - a)[0];
    if (bestStreak >= 3) cards.push({ icon: '🔥', title: `${bestStreak}-day streak going`, body: "You're building real momentum — don't break the chain today." });

    // Productivity score trend
    const score = DashboardManager.productivityScore();
    cards.push({ icon: '📈', title: `Productivity score: ${score}/100`, body: score >= 75 ? 'Excellent balance of focus, tasks, and habits this week.' : score >= 45 ? 'Solid progress — a bit more consistency will push this higher.' : 'Things have been quiet. Pick one small task to build momentum.' });

    return cards;
  },
  render() {
    $('#coachGrid').innerHTML = this.generate().map((c) => `<div class="coach-card card"><div class="coach-card-icon">${c.icon}</div><h4>${c.title}</h4><p>${c.body}</p></div>`).join('');
  },
  init() {
    $('#refreshCoachBtn').addEventListener('click', () => { this.render(); Toast.show('Insights refreshed.', 'info'); });
    Router.register('coach', () => this.render());
  },
};

/* ============================================================
   17. MUSIC MANAGER  (on-device ambient soundscapes via Web Audio API —
       no external audio files, fully compliant with "no dependencies")
   ============================================================ */
const SOUNDSCAPES = [
  { id: 'lofi', name: 'Lo-fi', desc: 'Warm chords for casual focus', icon: '🎧', activity: 'creative work' },
  { id: 'piano', name: 'Piano', desc: 'Soft generative piano tones', icon: '🎹', activity: 'reading' },
  { id: 'rain', name: 'Rain', desc: 'Steady rainfall noise', icon: '🌧', activity: 'deep work' },
  { id: 'nature', name: 'Nature', desc: 'Wind & birdsong texture', icon: '🌿', activity: 'breaks' },
  { id: 'ambient', name: 'Ambient', desc: 'Evolving drone pads', icon: '✨', activity: 'planning' },
  { id: 'meditation', name: 'Meditation', desc: 'Singing-bowl tones', icon: '🧘', activity: 'reflection' },
];

const MusicManager = {
  ctx: null, nodes: [], playingId: null, masterGain: null,

  ensureCtx() { if (!this.ctx) { this.ctx = new (window.AudioContext || window.webkitAudioContext)(); this.masterGain = this.ctx.createGain(); this.masterGain.gain.value = 0.5; this.masterGain.connect(this.ctx.destination); } },

  stop() {
    this.nodes.forEach((n) => { try { n.stop?.(); n.disconnect?.(); } catch (e) {} });
    this.nodes = [];
    this.playingId = null;
    $('#nowPlayingName').textContent = 'Nothing playing';
    $('#nowPlayingDesc').textContent = 'Pick a soundscape to begin';
    $$('.music-card').forEach((c) => c.classList.remove('is-playing'));
    $('#musicVisualizer').classList.remove('is-active');
  },

  play(id) {
    this.ensureCtx();
    this.stop();
    this.playingId = id;
    const ctx = this.ctx;
    const out = this.masterGain;

    const makeNoise = (filterType, freq) => {
      const bufferSize = 2 * ctx.sampleRate;
      const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) data[i] = Math.random() * 2 - 1;
      const noise = ctx.createBufferSource(); noise.buffer = buffer; noise.loop = true;
      const filter = ctx.createBiquadFilter(); filter.type = filterType; filter.frequency.value = freq;
      const gain = ctx.createGain(); gain.gain.value = 0.25;
      noise.connect(filter).connect(gain).connect(out);
      noise.start();
      this.nodes.push(noise, filter, gain);
      return gain;
    };
    const makeTone = (freq, type, gainVal, detune = 0) => {
      const osc = ctx.createOscillator(); osc.type = type; osc.frequency.value = freq; osc.detune.value = detune;
      const gain = ctx.createGain(); gain.gain.value = gainVal;
      osc.connect(gain).connect(out);
      osc.start();
      this.nodes.push(osc, gain);
      return { osc, gain };
    };

    if (id === 'rain') { makeNoise('lowpass', 1200); }
    else if (id === 'nature') { makeNoise('bandpass', 900); makeTone(2200, 'sine', 0.015); }
    else if (id === 'lofi') { makeTone(220, 'sine', 0.08); makeTone(277, 'triangle', 0.05); makeTone(330, 'sine', 0.05, 4); }
    else if (id === 'piano') {
      const notes = [261.6, 329.6, 392.0, 523.3];
      let i = 0;
      const playNote = () => { if (this.playingId !== 'piano') return; const { gain } = makeTone(notes[i % notes.length], 'triangle', 0.0001); const now = ctx.currentTime; gain.gain.linearRampToValueAtTime(0.09, now + 0.05); gain.gain.exponentialRampToValueAtTime(0.0001, now + 1.6); i++; setTimeout(playNote, 1800 + Math.random() * 800); };
      playNote();
    } else if (id === 'ambient') { makeTone(110, 'sine', 0.06); makeTone(165, 'sine', 0.04, 6); makeTone(220, 'triangle', 0.02, -6); }
    else if (id === 'meditation') {
      const ring = () => { if (this.playingId !== 'meditation') return; const { gain } = makeTone(432, 'sine', 0.0001); const now = ctx.currentTime; gain.gain.linearRampToValueAtTime(0.12, now + 0.3); gain.gain.exponentialRampToValueAtTime(0.0001, now + 4); setTimeout(ring, 5000); };
      ring();
    }

    const meta = SOUNDSCAPES.find((s) => s.id === id);
    $('#nowPlayingName').textContent = meta.name;
    $('#nowPlayingDesc').textContent = meta.desc;
    $$('.music-card').forEach((c) => c.classList.toggle('is-playing', c.dataset.id === id));
    $('#musicVisualizer').classList.add('is-active');
    Activity.log('music', `Started playing ${meta.name} soundscape`, '♫');
  },

  recommendation() {
    const hour = new Date().getHours();
    if (hour < 9) return 'piano';
    if (hour < 13) return 'lofi';
    if (hour < 17) return 'rain';
    if (hour < 20) return 'ambient';
    return 'meditation';
  },

  render() {
    const rec = this.recommendation();
    $('#musicGrid').innerHTML = SOUNDSCAPES.map((s) => `
      <div class="music-card card ${this.playingId === s.id ? 'is-playing' : ''}" data-id="${s.id}">
        <div class="music-card-icon">${s.icon}</div>
        <h4>${s.name}</h4>
        <p>${s.desc}</p>
        ${s.id === rec ? '<span class="chip" style="margin-top:8px">✦ Recommended now</span>' : ''}
      </div>`).join('');
    $('#musicVisualizer').innerHTML = Array.from({ length: 5 }).map((_, i) => `<span style="height:${8 + i * 4}px; animation-delay:${i * 0.12}s"></span>`).join('');
  },

  init() {
    this.render();
    $('#musicGrid').addEventListener('click', (e) => { const c = e.target.closest('.music-card'); if (!c) return; if (this.playingId === c.dataset.id) this.stop(); else this.play(c.dataset.id); });
    $('#musicVolume').addEventListener('input', (e) => { this.ensureCtx(); this.masterGain.gain.value = e.target.value / 100; });
    $('#musicStopBtn').addEventListener('click', () => this.stop());
    Router.register('music', () => this.render());
  },
};

/* ============================================================
   18. PROFILE MANAGER
   ============================================================ */
const ProfileManager = {
  fileToBase64(file) { return new Promise((resolve, reject) => { const r = new FileReader(); r.onload = () => resolve(r.result); r.onerror = reject; r.readAsDataURL(file); }); },

  totals() {
    const s = S();
    const focusMs = s.sessions.reduce((a, x) => a + x.activeMs, 0);
    return {
      tasksCompleted: s.tasks.filter((t) => t.status === 'done').length,
      focusHours: (focusMs / 3.6e6).toFixed(1),
      projects: s.projects.length,
      longestStreak: Math.max(0, ...s.habits.map((h) => computeStreak(h).longest)),
      currentStreak: Math.max(0, ...s.habits.map((h) => computeStreak(h).current)),
      score: DashboardManager.productivityScore(),
    };
  },

  render() {
    const p = S().profile;
    $('#profileName').textContent = p.name;
    $('#profileHandle').textContent = p.handle;
    $('#profileBio').textContent = p.bio;
    $('#profileProfession').textContent = p.profession;
    $('#profileJoinDate').textContent = `Joined ${p.joinDate}`;
    $('#profileAvatarImg').src = p.avatar || defaultAvatar();
    $('#avatarImg').src = p.avatar || defaultAvatar();
    $('#bannerImg').style.background = p.banner ? `url(${p.banner}) center/cover` : '';
    $('#profileSkills').innerHTML = p.skills.map((sk) => `<span class="chip">${escapeHtml(sk)}</span>`).join('') + `<button class="chip" id="addSkillBtn" style="cursor:pointer">+ Add</button>`;
    $('#profileLinks').innerHTML = p.links.map((l) => `<a href="${escapeHtml(l.url)}" target="_blank" rel="noopener">${escapeHtml(l.label)} ↗</a>`).join('') + ` <button class="link-btn" id="addLinkBtn" style="cursor:pointer">+ Add link</button>`;

    const t = this.totals();
    $('#profileStats').innerHTML = [
      ['Productivity score', t.score], ['Focus hours', t.focusHours], ['Tasks done', t.tasksCompleted],
      ['Projects', t.projects], ['Current streak', `${t.currentStreak}d`], ['Longest streak', `${t.longestStreak}d`],
    ].map(([label, val]) => `<div class="card"><div class="stat-label">${label}</div><div class="stat-big" style="font-size:1.4rem">${val}</div></div>`).join('');

    HeatmapComponent.render($('#profileHeatmap'), 365);

    $('#achievementsGrid').innerHTML = ACHIEVEMENT_DEFS.map((a) => {
      const unlocked = !!S().gamification.unlocked[a.id];
      return `<div class="badge ${unlocked ? 'is-unlocked' : ''}" title="${a.label}">${a.icon}<div class="badge-label">${a.label}</div></div>`;
    }).join('');

    $('#activityTimeline').innerHTML = S().activity.slice(0, 30).map((a) => `
      <div class="activity-feed-item">
        <div class="activity-feed-icon">${a.icon}</div>
        <div><div>${escapeHtml(a.text)}</div><div class="activity-feed-time">${timeAgo(a.ts)}</div></div>
      </div>`).join('') || '<p class="muted">No activity yet — start a task or habit!</p>';
  },

  init() {
    ['profileName', 'profileHandle', 'profileBio', 'profileProfession'].forEach((id) => {
      $(`#${id}`).addEventListener('blur', () => {
        const map = { profileName: 'name', profileHandle: 'handle', profileBio: 'bio', profileProfession: 'profession' };
        S().profile[map[id]] = $(`#${id}`).textContent.trim();
        persist();
      });
    });
    $('.profile-avatar-wrap').addEventListener('click', () => $('#profileAvatarInput').click());
    $('#profileAvatarInput').addEventListener('change', async (e) => { const f = e.target.files[0]; if (!f) return; S().profile.avatar = await this.fileToBase64(f); persist(); this.render(); });
    $('#bannerInput').addEventListener('change', async (e) => { const f = e.target.files[0]; if (!f) return; S().profile.banner = await this.fileToBase64(f); persist(); this.render(); });
    $('#profileSkills').addEventListener('click', (e) => { if (e.target.id === 'addSkillBtn') { const v = prompt('Add a skill:'); if (v) { S().profile.skills.push(v); persist(); this.render(); } } });
    $('#profileLinks').addEventListener('click', (e) => { if (e.target.id === 'addLinkBtn') { const label = prompt('Link label (e.g. Dribbble):'); if (!label) return; const url = prompt('URL:'); if (!url) return; S().profile.links.push({ label, url }); persist(); this.render(); } });
    Router.register('profile', () => this.render());
  },
};
function defaultAvatar() { return 'data:image/svg+xml,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="110" height="110"><rect width="100%" height="100%" fill="%237c6cf6"/><text x="50%" y="58%" font-size="46" fill="white" text-anchor="middle" font-family="sans-serif">?</text></svg>'); }
function timeAgo(ts) {
  const s = Math.floor((Date.now() - ts) / 1000);
  if (s < 60) return 'just now';
  if (s < 3600) return `${Math.floor(s / 60)}m ago`;
  if (s < 86400) return `${Math.floor(s / 3600)}h ago`;
  return `${Math.floor(s / 86400)}d ago`;
}

/* ============================================================
   19. NOTIFICATIONS
   ============================================================ */
const NotificationManager = {
  checked: new Set(),
  check() {
    const s = S();
    const now = new Date();
    const soon = addDays(now, 1);
    if (s.settings.notifTasks) {
      s.tasks.filter((t) => t.status !== 'done' && t.dueDate && t.dueDate <= dateKey(soon)).forEach((t) => {
        const key = `task-${t.id}`;
        if (!this.checked.has(key)) { this.checked.add(key); this.push(`"${t.title}" is due ${t.dueDate === dateKey(now) ? 'today' : 'soon'}.`, '✓'); }
      });
    }
    if (s.settings.notifHabits) {
      const todayKey = dateKey(now);
      if (now.getHours() >= 20) {
        s.habits.filter((h) => !h.log[todayKey]).forEach((h) => {
          const key = `habit-${h.id}-${todayKey}`;
          if (!this.checked.has(key)) { this.checked.add(key); this.push(`Don't forget your habit: "${h.name}"`, '⟲'); }
        });
      }
    }
  },
  push(text, icon) {
    S().notifications.unshift({ id: uid(), text, icon, ts: Date.now(), read: false });
    S().notifications = S().notifications.slice(0, 50);
    persist();
    this.renderBell();
    if (typeof Notification !== 'undefined' && Notification.permission === 'granted') new Notification('Flow', { body: text });
  },
  renderBell() {
    const unread = S().notifications.filter((n) => !n.read).length;
    $('#notifDot').hidden = unread === 0;
  },
  renderPanel() {
    const list = $('#notifList');
    list.innerHTML = S().notifications.length ? S().notifications.map((n) => `<div class="notif-item">${n.icon} ${escapeHtml(n.text)}<span class="notif-time">${timeAgo(n.ts)}</span></div>`).join('') : '<p class="muted" style="font-size:.82rem">You\'re all caught up.</p>';
    S().notifications.forEach((n) => (n.read = true));
    persist();
    this.renderBell();
  },
  init() {
    this.renderBell();
    setInterval(() => this.check(), 60000);
    this.check();
    $('#notifBtn').addEventListener('click', () => { const panel = $('#notifPanel'); panel.hidden = !panel.hidden; if (!panel.hidden) this.renderPanel(); });
    $('#clearNotifsBtn').addEventListener('click', () => { S().notifications = []; persist(); this.renderPanel(); });
    document.addEventListener('click', (e) => { if (!e.target.closest('#notifPanel') && !e.target.closest('#notifBtn')) $('#notifPanel').hidden = true; });
  },
};

/* ============================================================
   20. DASHBOARD MANAGER  (draggable widget grid)
   ============================================================ */
const WIDGET_DEFS = {
  goalTimer: { title: 'Focus Timer', size: 'wide', render: widgetTimer },
  productivityScore: { title: 'Productivity Score', size: 'small', render: widgetScore },
  todayHours: { title: "Today's Hours", size: 'small', render: widgetTodayHours },
  upcomingTasks: { title: 'Upcoming Tasks', size: 'medium', render: widgetUpcoming },
  habitProgress: { title: 'Habit Progress', size: 'medium', render: widgetHabits },
  weeklyAnalytics: { title: 'Weekly Analytics', size: 'wide', render: widgetWeekly },
  weather: { title: 'Weather', size: 'small', render: widgetWeather },
  recentActivity: { title: 'Recent Activity', size: 'medium', render: widgetActivity },
};
const SIZE_CLASS = { small: 'small', medium: '', wide: 'wide', full: 'full' };

function widgetTimer() {
  const t = WorkTracker.timer;
  const tasks = S().tasks.filter((x) => x.status !== 'done');
  return `
    <select class="select-input timer-task-select" id="wTimerTaskSelect" ${t ? 'disabled' : ''}>
      <option value="">No specific task</option>
      ${tasks.map((x) => `<option value="${x.id}" ${t?.taskId === x.id ? 'selected' : ''}>${escapeHtml(x.title)}</option>`).join('')}
    </select>
    <div class="timer-widget-display" id="wTimerDisplay">${formatDuration(WorkTracker.currentElapsed())}</div>
    <div class="timer-controls">
      ${!t ? `<button class="btn btn-primary" id="wTimerStart">▶ Start</button>`
        : t.state === 'running' ? `<button class="btn btn-ghost" id="wTimerPause">⏸ Pause</button><button class="btn btn-primary" id="wTimerComplete">✓ Complete</button>`
        : `<button class="btn btn-ghost" id="wTimerResume">▶ Resume</button><button class="btn btn-primary" id="wTimerComplete">✓ Complete</button>`}
    </div>`;
}
function widgetScore() {
  const score = DashboardManager.productivityScore();
  const c = 2 * Math.PI * 40;
  return `<div class="ring-wrap">
    <svg class="ring-svg" viewBox="0 0 96 96">
      <circle cx="48" cy="48" r="40" fill="none" stroke="hsl(var(--accent-h) 30% 50% / .15)" stroke-width="8"/>
      <circle cx="48" cy="48" r="40" fill="none" stroke="var(--accent)" stroke-width="8" stroke-linecap="round" stroke-dasharray="${c}" stroke-dashoffset="${c - (score / 100) * c}" transform="rotate(-90 48 48)"/>
    </svg>
    <div><div class="stat-big">${score}</div><div class="stat-label">out of 100 today</div></div>
  </div>`;
}
function widgetTodayHours() {
  const todayKey = dateKey(new Date());
  const ms = S().sessions.filter((s) => dateKey(new Date(s.start)) === todayKey).reduce((a, s) => a + s.activeMs, 0) + WorkTracker.currentElapsed();
  return `<div class="stat-row"><span class="stat-big">${formatHoursShort(ms)}</span></div><p class="stat-label">focused today</p>`;
}
function widgetUpcoming() {
  const list = S().tasks.filter((t) => t.status !== 'done').sort((a, b) => (a.dueDate || '9999').localeCompare(b.dueDate || '9999')).slice(0, 5);
  if (!list.length) return `<p class="muted">Nothing upcoming — nice and clear.</p>`;
  return `<div class="mini-list">${list.map((t) => `<div class="mini-list-item"><span class="dot" style="background:${{ Critical: 'var(--critical)', High: 'var(--high)', Medium: 'var(--medium)', Low: 'var(--low)' }[t.priority]}"></span><span style="flex:1">${escapeHtml(t.title)}</span><span class="muted">${t.dueDate || '—'}</span></div>`).join('')}</div>`;
}
function widgetHabits() {
  const habits = S().habits;
  if (!habits.length) return `<p class="muted">No habits tracked yet.</p>`;
  const todayKey = dateKey(new Date());
  return `<div class="habit-progress-mini">${habits.map((h) => `<div class="habit-progress-row"><span style="width:70px;flex-shrink:0">${escapeHtml(h.name.slice(0, 10))}</span><div class="habit-progress-track"><div class="habit-progress-fill" style="width:${HabitManager.completionRate(h, 30)}%; background:${h.color}"></div></div><span>${h.log[todayKey] ? '✓' : ''}</span></div>`).join('')}</div>`;
}
function widgetWeekly() {
  return `<canvas id="wWeeklyCanvas" width="700" height="180"></canvas>`;
}
function widgetWeather() {
  const w = ThemeManager.weatherData;
  if (!w) return '';
  return `<div class="weather-widget-body">
      <div><div class="weather-icon-big">${WEATHER_ICONS[ThemeManager.currentWeather]}</div><div class="stat-label">${WEATHER_LABELS[ThemeManager.currentWeather]}</div></div>
      <div class="stat-big">${w.temp}°</div>
    </div>
    <div class="weather-detail-grid">
      <span>Humidity: ${w.humidity}%</span><span>Wind: ${w.wind} km/h</span>
      <span>UV index: ${w.uv}</span><span>Air quality: ${w.aqi}</span>
      <span>Sunrise: ${w.sunrise}</span><span>Sunset: ${w.sunset}</span>
    </div>`;
}
function widgetActivity() {
  const items = S().activity.slice(0, 8);
  if (!items.length) return `<p class="muted">Your activity feed will appear here.</p>`;
  return `<div class="activity-feed">${items.map((a) => `<div class="activity-feed-item"><div class="activity-feed-icon">${a.icon}</div><div><div>${escapeHtml(a.text)}</div><div class="activity-feed-time">${timeAgo(a.ts)}</div></div></div>`).join('')}</div>`;
}

const DashboardManager = {
  draggedId: null,

  productivityScore() {
    const s = S();
    const todayKey = dateKey(new Date());
    const tasksDoneToday = s.tasks.filter((t) => t.status === 'done').length ? s.tasks.filter((t) => t.status === 'done' && dateKey(new Date(t.createdAt)) === todayKey).length : 0;
    const focusMsToday = s.sessions.filter((x) => dateKey(new Date(x.start)) === todayKey).reduce((a, x) => a + x.activeMs, 0);
    const habitsToday = s.habits.length ? s.habits.filter((h) => h.log[todayKey]).length / s.habits.length : 0;
    const taskScore = clamp(tasksDoneToday * 15, 0, 40);
    const focusScore = clamp((focusMsToday / 3.6e6) * 12, 0, 40);
    const habitScore = habitsToday * 20;
    return clamp(Math.round(taskScore + focusScore + habitScore), 0, 100);
  },

  render() {
    const order = S().settings.widgetOrder.filter((id) => WIDGET_DEFS[id]);
    const grid = $('#dashGrid');
    grid.innerHTML = order.map((id) => {
      const def = WIDGET_DEFS[id];
      return `<div class="widget card" draggable="true" data-widget="${id}" data-size="${def.size}">
        <div class="widget-head"><h3>${def.title}</h3><span class="widget-drag-handle">⠿</span></div>
        <div class="widget-body">${def.render()}</div>
      </div>`;
    }).join('');
    this.wireWidgetEvents();
    this.wireDnd();
    // Weekly analytics mini-chart needs its own canvas draw pass after insertion
    const wCanvas = $('#wWeeklyCanvas');
    if (wCanvas) {
      const vals = Array.from({ length: 7 }).map((_, i) => {
        const key = dateKey(addDays(new Date(), -(6 - i)));
        return +(S().sessions.filter((s) => dateKey(new Date(s.start)) === key).reduce((a, s) => a + s.activeMs, 0) / 3.6e6).toFixed(2);
      });
      const labels = Array.from({ length: 7 }).map((_, i) => addDays(new Date(), -(6 - i)).toLocaleDateString([], { weekday: 'short' }));
      ChartRenderer.bar(wCanvas, vals, { labels, color: 'var(--accent)' });
    }
    // goal input
    $('#todayGoalInput').value = S().goals[dateKey(new Date())] || '';
  },

  wireWidgetEvents() {
    const grid = $('#dashGrid');
    const startBtn = $('#wTimerStart', grid);
    if (startBtn) startBtn.addEventListener('click', () => WorkTracker.start($('#wTimerTaskSelect').value || null));
    const pauseBtn = $('#wTimerPause', grid); if (pauseBtn) pauseBtn.addEventListener('click', () => WorkTracker.pause());
    const resumeBtn = $('#wTimerResume', grid); if (resumeBtn) resumeBtn.addEventListener('click', () => WorkTracker.resume());
    const completeBtn = $('#wTimerComplete', grid); if (completeBtn) completeBtn.addEventListener('click', () => WorkTracker.complete());
  },

  wireDnd() {
    const grid = $('#dashGrid');
    $$('.widget', grid).forEach((w) => {
      w.addEventListener('dragstart', () => { this.draggedId = w.dataset.widget; w.classList.add('is-dragging'); });
      w.addEventListener('dragend', () => w.classList.remove('is-dragging'));
      w.addEventListener('dragover', (e) => { e.preventDefault(); w.classList.add('widget-drop-target'); });
      w.addEventListener('dragleave', () => w.classList.remove('widget-drop-target'));
      w.addEventListener('drop', (e) => {
        e.preventDefault();
        w.classList.remove('widget-drop-target');
        const targetId = w.dataset.widget;
        if (!this.draggedId || this.draggedId === targetId) return;
        const order = S().settings.widgetOrder;
        const from = order.indexOf(this.draggedId);
        const to = order.indexOf(targetId);
        order.splice(from, 1);
        order.splice(to, 0, this.draggedId);
        persist();
        this.render();
      });
    });
  },

  init() {
    $('#todayGoalInput').addEventListener('input', debounce((e) => { S().goals[dateKey(new Date())] = e.target.value; persist(); }, 400));
    Router.register('dashboard', () => this.render());
    // live-refresh certain widgets every second while a timer runs
    Bus.on('timer:tick', () => {
      const disp = $('#wTimerDisplay');
      if (disp) disp.textContent = formatDuration(WorkTracker.currentElapsed());
    });
    Bus.on('timer:changed', () => { if (Router.current === 'dashboard') this.render(); });
  },
};

/* ============================================================
   21. SETTINGS MANAGER
   ============================================================ */
const ACCENTS = [252, 210, 150, 340, 25, 190];
const SettingsManager = {
  syncControls() {
    const s = S().settings;
    $('#themeModeSelect').value = s.themeMode;
    $('#weatherModeSelect').value = s.weatherMode;
    $('#animationsToggle').checked = s.animations;
    $('#notifTasksToggle').checked = s.notifTasks;
    $('#notifHabitsToggle').checked = s.notifHabits;
    $('#languageSelect').value = s.language;
    $('#weekStartSelect').value = String(s.weekStart);
    $('#accentSwatches').innerHTML = ACCENTS.map((h) => `<button type="button" class="accent-swatch ${s.accentH === h ? 'is-selected' : ''}" data-h="${h}" style="background:hsl(${h} 80% 62%)"></button>`).join('');
  },
  init() {
    this.syncControls();
    $('#themeModeSelect').addEventListener('change', (e) => { S().settings.themeMode = e.target.value; persist(); ThemeManager.apply(); });
    $('#weatherModeSelect').addEventListener('change', (e) => { S().settings.weatherMode = e.target.value; persist(); ThemeManager.apply(); });
    $('#animationsToggle').addEventListener('change', (e) => { S().settings.animations = e.target.checked; persist(); ThemeManager.apply(); });
    $('#notifTasksToggle').addEventListener('change', (e) => { S().settings.notifTasks = e.target.checked; persist(); });
    $('#notifHabitsToggle').addEventListener('change', (e) => { S().settings.notifHabits = e.target.checked; persist(); });
    $('#languageSelect').addEventListener('change', (e) => { S().settings.language = e.target.value; persist(); Toast.show('Language preference saved. (UI translation coming soon.)', 'info'); });
    $('#weekStartSelect').addEventListener('change', (e) => { S().settings.weekStart = Number(e.target.value); persist(); CalendarManager.render(); });
    $('#accentSwatches').addEventListener('click', (e) => { const b = e.target.closest('.accent-swatch'); if (!b) return; S().settings.accentH = Number(b.dataset.h); persist(); ThemeManager.apply(); this.syncControls(); });
    $('#enableBrowserNotifBtn').addEventListener('click', async () => {
      if (!('Notification' in window)) { Toast.show('Notifications are not supported in this browser.', 'error'); return; }
      const perm = await Notification.requestPermission();
      Toast.show(perm === 'granted' ? 'Browser notifications enabled.' : 'Permission not granted.', perm === 'granted' ? 'success' : 'error');
    });
    $('#exportDataBtn').addEventListener('click', () => {
      const blob = new Blob([JSON.stringify(S(), null, 2)], { type: 'application/json' });
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = `flow-backup-${dateKey(new Date())}.json`;
      a.click();
      URL.revokeObjectURL(a.href);
    });
    $('#importDataInput').addEventListener('change', async (e) => {
      const file = e.target.files[0]; if (!file) return;
      try {
        const text = await file.text();
        const parsed = JSON.parse(text);
        store.state = { ...DEFAULT_STATE(), ...parsed };
        store.save();
        Toast.show('Data imported. Reloading…', 'success');
        setTimeout(() => location.reload(), 900);
      } catch (err) { Toast.show('Invalid backup file.', 'error'); }
      e.target.value = '';
    });
    $('#resetDataBtn').addEventListener('click', () => {
      if (confirm('This will erase all local data. Continue?')) { store.reset(); Toast.show('All data reset. Reloading…', 'info'); setTimeout(() => location.reload(), 800); }
    });
    Router.register('settings', () => this.syncControls());
  },
};

/* ============================================================
   22. GLOBAL SEARCH
   ============================================================ */
const SearchManager = {
  init() {
    $('#globalSearch').addEventListener('input', debounce((e) => {
      const q = e.target.value.trim().toLowerCase();
      TaskManager.filters.query = q;
      if (q && Router.current !== 'tasks') Router.goto('tasks');
      TaskManager.render();
    }, 250));
  },
};

/* ============================================================
   23. QUICK ADD (topbar shortcut)
   ============================================================ */
$('#quickAddBtn')?.addEventListener('click', () => TaskManager.openEditor());

/* ============================================================
   24. XP CHROME (sidebar level/xp bar — updates on any gamification change)
   ============================================================ */
function renderXpChrome() {
  const g = S().gamification;
  const needed = Gamification.xpForLevel(g.level);
  $('#levelLabel').textContent = `Lv. ${g.level}`;
  $('#xpLabel').textContent = `${g.xp} / ${needed} XP`;
  $('#xpBarFill').style.width = `${clamp((g.xp / needed) * 100, 0, 100)}%`;
}

/* ============================================================
   25. APP BOOTSTRAP
   ============================================================ */
const App = {
  init() {
    // Cross-cutting UI chrome first
    ThemeManager.init();
    ClockManager.init();
    Router.init();
    SettingsManager.init();

    // Feature managers (each wires its own DOM + registers its view renderer)
    TaskManager.init();
    ProjectManager.init();
    CalendarManager.init();
    HabitManager.init();
    JournalManager.init();
    AnalyticsManager.init();
    CoachManager.init();
    MusicManager.init();
    ProfileManager.init();
    DashboardManager.init();
    NotificationManager.init();
    SearchManager.init();
    WorkTracker.init();

    $('#themeToggleBtn').addEventListener('click', () => ThemeManager.cycleManual());

    Bus.on('gamification:changed', renderXpChrome);
    Bus.on('achievements:changed', () => { if (Router.current === 'profile') ProfileManager.render(); });
    Bus.on('activity:changed', () => { if (Router.current === 'profile') ProfileManager.render(); if (Router.current === 'dashboard') DashboardManager.render(); });
    Bus.on('habits:changed', () => { if (Router.current === 'analytics') AnalyticsManager.render(); if (Router.current === 'dashboard') DashboardManager.render(); AnalyticsManager.invalidate(); });
    Bus.on('tasks:changed', () => { AnalyticsManager.invalidate(); });

    renderXpChrome();
    Router.goto('dashboard');

    // Seed a friendly first-run experience if the user has no data at all
    if (!S().tasks.length && !S().projects.length && !localStorage.getItem('flow_seeded')) {
      this.seedDemoData();
      localStorage.setItem('flow_seeded', '1');
    }

    Toast.show('Welcome back — Flow is ready.', 'success', '〰');
  },

  seedDemoData() {
    const p = ProjectManager.create({ title: 'Personal Website', description: 'Redesign and relaunch my portfolio.', deadline: dateKey(addDays(new Date(), 21)) });
    ProjectManager.addMilestone(p.id, 'Wireframes approved', dateKey(addDays(new Date(), 3)));
    const t1 = TaskManager.create({ title: 'Draft homepage layout', priority: 'High', category: 'Design', dueDate: dateKey(addDays(new Date(), 1)), estDuration: 90, projectId: p.id, tags: ['design'] });
    TaskManager.create({ title: 'Write project case studies', priority: 'Medium', category: 'Writing', dueDate: dateKey(addDays(new Date(), 4)), estDuration: 60, projectId: p.id });
    TaskManager.create({ title: 'Reply to client emails', priority: 'Critical', category: 'Admin', dueDate: dateKey(new Date()), estDuration: 20 });
    HabitManager.create({ name: 'Morning walk', color: '#69db7c' });
    HabitManager.create({ name: 'Read 20 min', color: '#4dabf7' });
    CalendarManager.create({ title: 'Design review', date: dateKey(addDays(new Date(), 2)), time: '14:00', recurring: 'none', notes: 'Walk through homepage concepts.' });
    TaskManager.render(); ProjectManager.render(); HabitManager.render(); DashboardManager.render();
  },
};

document.addEventListener('DOMContentLoaded', () => App.init());
